"""
data_loader.py

the data_loader.py contains the definition for a DataProcessor object 
this object contains instance methods to check files it was given, 
as well as @staticmethods to provide general functionality to the program 
to process realtime and sequential data with provided bounds

The top of the file contians the DataProcessor class, as well as the @staticmethods 
for sequential file data processing 

The middle of the file contains the @staticmethods for realtime file data processing

The buttom of the file contains the instance methods for checking and processing given files
"""

import pandas as pd
import numpy as np
import csv
import os 
from multiprocessing import Pool, cpu_count
import traceback
import time as tm


class DataProcessor:
    """
    Allows the user to verify files are properly formatted sequential or realtime 
    data files. Utilizes pythonns Pool.map() function from it's multiprocessing library 
    to analyze, filter, and load data into pandas dataframes and metadata. 

    @staticmethods at the top of the file are general purpose for loading a file and do not require instantiation

    Instance methods at the bottom of the file are meant to be used when files need to be processed
    in the context of the Force Logic MDL Engineering Dashboard 
    """


    #how many cycles will be 'batched' together and sent to a worker to be processed.
    #recommended 1000 sequential and 500 for realtime for data sets > 50,000 cycles
    SEQUENTIAL_BATCH_SIZE = 1000
    REALTIME_BATCH_SIZE = 500

    def __init__(self):
        pass


# ================================= STATIC FUNCTIONS FOR BOTH REALTIME AND SEQUENTIAL MULTIPROCESSING =====================


    @staticmethod
    def batch_cycle_nums(total_cycles, max_batch_size):
        """
        chunks cycles into batches of max_batch_size.
        If there are not an evenly divisible amount of batches, a final batch of size n will be created
        Where (#ofbatches * max_batch_size) + n == total_cycles

        Args: 
            total_cycles (int): the total number of cycles to be batched 
            max_batch_size (int): the maximum size a batch of cycles can be in cycles

        Return: 
            A tuple of cycle indices for the batch (start, end). 
            start (int): index of cycle start in the realtime dataframe
            end (int): index of cycle end in the realtime dataframe

            yield produces only one at a time -- when requested from the pool() function
            in _load_[blank]_file(), and will remember what the values were the last time 
            it was called, ultimately iterating over all the cycles 
        """

        for start in range(0, total_cycles, max_batch_size):
            end = min(start  + max_batch_size, total_cycles)
            yield (start, end)


    @staticmethod
    def batch_cycle_args(args_list, batch_size):
        """
        Chunks the argument tuples in args_list 
        into batches of batch_size

        Args: 
            args_list (list): the full list of all the argument tuples needed for each cycle to be processed
                              in _process_raw_[blank]_cycle()
            batch_size (int): the number of argument tuples that will be acquired from the list
        
        Return: 
            A list of argument tuples of size batch_size

            yield produces only one at a time -- when requested from the pool() function
            in _load_[blank]_file(), and will remember what the index (i) was the last time 
            it was called, ultimately iterating over all the arguments in args_list
        """
        for i in range(0, len(args_list), batch_size):
            yield args_list[i:i + batch_size]












    # =================================== STATIC FUNCTIONS FOR SEQUENTIAL ===============================



    @staticmethod
    def _process_sequential_cycle_batch(batch):
        """
        Processes each of the cycles given in batch
        and collects the result from _process_raw_realtime_cycle
        for each cycle into one list

        Args: 
            batch (list): the list of cycle argument tuples corresponding to each cycle 
            to be processed in _process_raw_realtime_cycle

        return: 
            results (list): A list where each element is the return value of   
            _process_raw_[blank]_cycle
        """
        results = []
        for single_cycle_args in batch:
            result = DataProcessor._pass_sequential_args(single_cycle_args)
            results.append(result)
        return results




    @staticmethod
    def _pass_sequential_args(args):

        """
        Takes the cycle args tuple and calls 
        processes the cycle given those args

        Args: 
            The tuple of cycle args for a given cycle (including its start index
            in the dataframe)

        return: 
            Same return value as _process_raw_[blank]_cycle()
        """

        (
            sequential_dataframe,
            cols,
            row_index_of_cycle,
            application_id,
            current_bound_low,
            current_bound_high,
            significant_change_in_Amps,
            pressure_bound_low,
            pressure_bound_high,
            significant_change_in_PSI,
            distance_bound_low,
            distance_bound_high,
            significant_change_in_mm   
        ) = args
          

        return DataProcessor._process_raw_sequential_cycle(
            sequential_dataframe,
            cols,
            row_index_of_cycle,
            application_id,
            current_bound_low,
            current_bound_high,
            significant_change_in_Amps,
            pressure_bound_low,
            pressure_bound_high,
            significant_change_in_PSI,
            distance_bound_low,
            distance_bound_high,
            significant_change_in_mm
        )



    @staticmethod
    def _process_raw_sequential_cycle(sequential_dataframe, 
                                        cols, 
                                        row_index_of_cycle, 
                                        application_id,
                                        current_bound_low,
                                        current_bound_high,
                                        significant_change_in_Amps,
                                        pressure_bound_low,
                                        pressure_bound_high,
                                        significant_change_in_PSI,
                                        distance_bound_low,
                                        distance_bound_high,
                                        significant_change_in_mm
                                      ):
        

        """
        Analyzes the raw cycle data and compares against the arguments given 

        Args:
            sequential dataframe (pandas dataframe): The dataframe of the entire sequential data csv file 
            cols (list): the list of columns in the sequential dataframe
            row_index_of_cycle (int): the row index of the cycles data in the sequential dataframe 
            application_id (int): the application id of the cycle recorded from the file 

            See _load_sequential_file() docstring for remaining args 

        Returns: 
            0 (int): placeholder value, can be changed.

        """

        return 0
    
    @staticmethod 
    def _load_sequential_file(csv_file, 
                                current_bound_low,
                                current_bound_high,
                                significant_change_in_Amps,
                                pressure_bound_low,
                                pressure_bound_high,
                                significant_change_in_PSI,
                                distance_bound_low,
                                distance_bound_high,
                                significant_change_in_mm):

        """
        This function loads the data in 'csv_file' into a pandas dataframe 
        As the data is being read, this function compares it with the signed + unsignged types in 
        the 'New LUT Definition' Sheet. 
        
        Utilizing Pythons Pool library, this function will batch the cycles and their respective args 
        into size SEQUENTIAL_BATCH_SIZE and feed each batch of cycle args to a worker. The worker will 
        process its batch of cycles one by one, using the _process_raw_sequential_cycle() function, 
        sharing memory between each cycle in it's batch for speed. The worker will collect it's results 
        in a list, and each workers list will be flattened into one large list sequential_metadata


        Args: 
            
            csv_file (filepath): the filepath of the sequential CSV file to be processed

            NOTE: any point below _bound_low or above _bound_high is 
            recorded as out of bounds and will be corrected 

            current_bound_low (float): the low bound of current in A 
            current_bound_high (float): the high bound of current in A
            significant_change_in_A (float): the value that constitutes a significant change in A 
            pressure_bound_low (float):the low bound of pressure in PSI
            pressure_bound_high (float): the high bound of pressure in PSI
            significant_change_in_PSI (float): the value that constitutes a significant change in PSI
            distance_bound_low (float): the low bound of cycle distance in mm
            distance_bound_high (float): the hig hbound of cycle distance in mm
            significant_change_in_mm (float): the value that constitutes a significant change in mm

        Returns: 
            tuple: 
            sequential_dataframe (pandas dataframe): the dataframe representation of the sequential CSV file
            sequential_metadata (list): a list of three dicts for the three categories of enumerated types 
                in the CSV files I have seen. {enumeration value in hex: corresponding string it maps to}


        TODO FOR IMPROVEMENTS
         - timestamp conversion from decimal value to actual date
         - use AI for data filtering and marking of odd values
         - make it adaptable for more parameters to be added (adding a new variable dtype map, combine with 'all' map below )
         - pull the data typing parameters from quick link website itself would be cool 
        """

        start_processing_file = tm.time()
 
        #get headers in a list 
        actual_headers = [h.strip() for h in pd.read_csv(csv_file, nrows=0).columns.tolist()]

        #Trimming down size when possible by forcing entries into smaller datatypes using this map
        #Headers commented out assumed to be 64 bit ints (pandas deataframe default)
        all_sequential_dtype_map = {
            "ApplicationId" :                       np.uint32,
            "Start RT Address" :                    np.uint32,
            "End RT Address" :                      np.uint32, 
            # Application Timestamp
            "Pressure Maximum (PSI)" :              np.int16,
            "Cycle Start Pressure (PSI)" :          np.int16,
            "Pressure Spike Counts (Number)" :      np.uint16,
            "Peak Mapped Pressure (PSI)" :          np.int16,
            # Grade (Unitless)              (see convertor below)
            # Dump Reason (Unitless)        (see convertor below)  
            # Tool Stop Reason (Unitless)   (see convertor below)
            "Cycle Distance (um)" :                 np.uint16,
            "Pressure Differential Average Under 3K PSI (PSI/ms)" : np.uint16, 
            "Current at 1kPSI (A)" :                np.int16,
            "Current at 3kPSI (A)" :                np.int16,
            "Current at 8kPSI (A)" :                np.int16,
            "Hydraulic Work (mJ)" :                 np.int8,
            # Battery MPBID (Unitless)"     
            "Initial Battery Voltage  (mV)" :       np.int32,
            "Miminum Pack Voltage (mV)" :           np.int32, 
            "Maximum Pack Voltage (mV)" :           np.int32,
            "End Battery Voltage (mV)" :            np.int32,
            "Battery Temp (C)" :                    np.int16, 
            "Battery Complete Charges (charges)" :  np.uint16, 
            "Battery Days of Service (days)" :      np.uint16, 
            "Battery Cycles Charging (cycles)" :    np.uint16, 
            "Measured Battery ACIR - Cycle Start (mOhm)" :          np.uint16,
            "Adjusted Battery DCIR (mOhm)" :        np.uint16,
            "Electrical Energy Total (W)" :         np.int16,
            "Total Motor Revolutions (revolutions)":np.uint16, 
            "Revolutions Below 2kPSI (revolutions)":np.uint16,
            "Pressure Rate of Change at 1kPSI (PSI/rev)" :          np.int16,
            "Pressure Rate of Change at 3kPSI (PSI/rev)" :          np.int16,
            "Pressure Rate of Change at 8kPSI (PSI/rev)" :          np.int16,
            "Cycle Start Temperature - MCU (deg C) (C)"  :          np.int16,
            "Cycle End Temperature - MCU (deg C) (C)" :             np.int16,
            "Cycle Start Temperature - Heatsink (deg C) (C)" :      np.int16,
            "Cycle End Temperature - Heatsink (deg C) (C)" :        np.int16,
            "3V3_SW Regulator Voltage (mV)" :       np.int32,
            "Cycle Peak Current  (Amps)" :          np.int16,
            "Num Trig Pulls (Number)" :             np.uint16, 
            "Application Duration (ms)" :           np.uint32, 
            # Sequential Packet CRC (Number)
            # Calculated CRC
        }

        # Trims down the dtype map to only the headers that were provided in the sequential file from the user 
        safe_sequential_dtype_map = {col: dtype for col, dtype in all_sequential_dtype_map.items() if col in actual_headers}

        script_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(script_dir, "ADL Variable Enums.xlsx")
        #reding the ADL Variable Enums excel sheet to equate strings from CSV to enumerations
        enum_df = pd.read_excel(file_path, sheet_name="Sheet1", header=None)
        enum_map_lower, grade_enum_dict, cycle_end_enum_dict, stop_enum_dict = DataProcessor.extract_enum_blocks(enum_df)

        #Converts strings to enums based on the enum map collected above
        #Will only convert the columns listed below if they are present 
        all_sequential_converter_map = {
            "Grade (Unitless)": lambda val: enum_map_lower.get(str(val).strip().replace(" ","").lower(), val ),
            "Dump Reason (Unitless)": lambda val: enum_map_lower.get(str(val).strip().replace(" ","").lower(), val),
            "Tool Stop Reason (Unitless)": lambda val: enum_map_lower.get(str(val).strip().replace(" ","").lower(), val),
            "Double Tap Trigger Status (Unitless)": lambda val: enum_map_lower.get(str(val).strip().replace(" ","").lower(), val),
        }

        #Trims down the converter map to only the headers that were provided in the sequential file from the user  
        safe_sequential_converter_map = {col: func for col, func in all_sequential_converter_map.items() if col in actual_headers}

        #read csv file, converting the data read in each column to it's type defined in the dtype_map
        #   or it's enumeration in converter_map
        sequential_dataframe = pd.read_csv(csv_file, 
                                           dtype=safe_sequential_dtype_map, 
                                           converters=safe_sequential_converter_map)
        
    
        
        #get column header strings in list to pass to _process() function
        sequential_dataframe.columns = sequential_dataframe.columns.str.strip()
        cols = sequential_dataframe.columns.tolist()

        Application_Ids = sequential_dataframe['ApplicationId']

        actual_num_of_cycles = sequential_dataframe.shape[0] # in sequential file each row is one cycle
        batch_size = DataProcessor.SEQUENTIAL_BATCH_SIZE

        for batch_start, batch_end in DataProcessor.batch_cycle_nums(actual_num_of_cycles, batch_size):
            print(f"Batch cycles from {batch_start} to {batch_end - 1} (size {batch_end - batch_start})")

        sequential_args = [
            (
                sequential_dataframe,
                cols,
                cycle_index,
                Application_Ids.iloc[cycle_index],
                current_bound_low,
                current_bound_high,
                significant_change_in_Amps,
                pressure_bound_low,
                pressure_bound_high,
                significant_change_in_PSI,
                distance_bound_low,
                distance_bound_high,
                significant_change_in_mm

            )

            for cycle_index in range(len(sequential_dataframe))
        ]

        #generating the batches of args to be used for multiprocessing
        args_batches = list(DataProcessor.batch_cycle_args(sequential_args, batch_size))

        #Multiprocessing
        with Pool(cpu_count()) as pool:
            batch_results = pool.map(DataProcessor._process_sequential_cycle_batch, args_batches)

        #flattened list of all the results of a cycle. each element contains the cycle num and 4 dicts return that each cycle returns
        sequential_metadata = [item for sublist in batch_results for item in sublist]

        print(f"Elapsed processing time for whole file: {tm.time() - start_processing_file:.2f} sec")

        #flip all items in the three dicts so they can be accessible by the enum values instead of the status strings
        enum_keys_grade_enum_dict = {enum_value : grade for grade, enum_value in grade_enum_dict.items()} 
        enum_keys_cycle_end_enum_dict = {enum_value : end_reason for end_reason, enum_value in cycle_end_enum_dict.items()}
        enum_keys_stop_enum_dict = {enum_value : stop_reason for stop_reason, enum_value in stop_enum_dict.items()}  

        #create the metadata 
        sequential_metadata = [enum_keys_grade_enum_dict, enum_keys_cycle_end_enum_dict, enum_keys_stop_enum_dict]

        return sequential_dataframe, sequential_metadata
    
    
    @staticmethod 
    def extract_enum_blocks(df):
        """
        Generates four dicts that map a string to an enum value
        from the ADL Variable Enums excel file 

        Args: 
            df (pandas dataframe): the dataframe representation of the 
            ADL Variable Enums fi
        
        Returns: 
            enum_map (dict): maps all names to their hex enumerated values (values can be duplicates)
            grade_enum_dict (dict): maps all Crimp Grade strings to their hex enumerated values 
            cycle_end_enum_dict (dict): maps all Cycle End Reason strings to their hex enumerated values 
            stop_enum_dict (dict): maps all Tool Stop Reason strings to their hex enumerated values
        """
        enum_map = {}
        grade_enum_dict = {}
        cycle_end_enum_dict = {}
        stop_enum_dict = {}
        i = 0
        while i < len(df):
            cell = df.iloc[i, 0]
            if isinstance(cell, str) and cell.endswith("Enum"):
                enum_name = cell.strip().lower()
                i += 1  # skip to header row
                if i + 1 >= len(df):
                    break
                headers = df.iloc[i]
                if "Name" in headers.values and "Value" in headers.values:
                    name_col = headers[headers == "Name"].index[0]
                    value_col = headers[headers == "Value"].index[0]
                    i += 1

                    target_dict = enum_map

                    if "crimp" in enum_name or "grade" in enum_name:
                        target_dict = grade_enum_dict
                    elif "cycleend" in enum_name:
                        target_dict = cycle_end_enum_dict
                    elif "stop" in enum_name or "toolstop" in enum_name:
                        target_dict = stop_enum_dict


                    # Read until next empty row
                    while i < len(df) and pd.notnull(df.iloc[i, name_col]):
                        name = str(df.iloc[i, name_col]).strip()
                        name_key = name.lower().replace(" ", "")
                        enum_value = df.iloc[i, value_col]
                        enum_map[name_key] = enum_value # need all in the enum map for data conversion,
                        target_dict[name_key]= enum_value

                        i += 1
                else:
                    i += 1
            else:
                i += 1
        return enum_map, grade_enum_dict, cycle_end_enum_dict, stop_enum_dict
        













    # ==================================== STATIC FUNCTIONS FOR REALTIME =================================




    @staticmethod
    def _get_realtime_cycle_from_dataframe(realtime_dataframe, cycle_row_start_index, next_cycle_row_start_index):
        """
        Retrieves the data for a single cycle beginning at cycle_row_start_index from
            the provided dataframe

        Args: 
            realtime_dataframe (pandas dataframe): the realtime dataframe that others 
            cycle_row_start_index (int): the row index the cycle begins on in the realtime_dataframe 
            next_cycle_row_start_index (int): the row index the next cycle begins on in the realtime_dataframe
                This arg is based on when the Application Id changes values. 
        
        Returns: 
            Returns a 2D Numpy array of the individual cycle data from the dataframe 

        """

        raw_cycle_data = realtime_dataframe.iloc[cycle_row_start_index:next_cycle_row_start_index]
        num_rows = next_cycle_row_start_index - cycle_row_start_index

        return raw_cycle_data.to_numpy(), num_rows
    

    
    @staticmethod
    def _process_realtime_cycle_batch(batch):
        """
        Processes each of the cycles given in batch
        and collects the result from _process_raw_realtime_cycle
        for each cycle into one list

        Args: 
            batch (list): the list of cycle argument tuples corresponding to each cycle 
            to be processed in _process_raw_realtime_cycle

        return: 
            results (list): A list where each element is the return value of   
            _process_raw_[blank]_cycle
        """
        results = []
        for single_args in batch:
            result = DataProcessor.pass_realtime_args(single_args)
            results.append(result)
        return results




    @staticmethod
    def pass_realtime_args(args):
        """
        Takes the cycle args tuple and calls 
        processes a cycle given those args

        Args: 
            The tuple of cycle args for a given cycle (including its start index
            in the dataframe)

        return: 
            Same return value as _process_raw_[blank]_cycle()
        """
        (   realtime_dataframe,
            cols,
            application_id,
            start_index,
            next_start_index,
            pressure_bound_low,
            pressure_bound_high,
            current_bound_low,
            current_bound_high,
            distance_bound_low,
            distance_bound_high,
            significant_change_in_PSI,
            significant_change_in_Amps,
            significant_change_in_mm
        ) = args
          

        return DataProcessor._process_raw_realtime_cycle(
            realtime_dataframe,
            cols,
            application_id,
            start_index,
            next_start_index,
            pressure_bound_low,
            pressure_bound_high,
            current_bound_low,
            current_bound_high,
            distance_bound_low,
            distance_bound_high,
            significant_change_in_PSI,
            significant_change_in_Amps,
            significant_change_in_mm
        )


    @staticmethod 
    def _process_raw_realtime_cycle(realtime_dataframe, 
            cols,
            application_id,
            start_index,
            next_start_index,
            pressure_bound_low,
            pressure_bound_high,
            current_bound_low,
            current_bound_high,
            distance_bound_low,
            distance_bound_high,
            significant_change_in_PSI,
            significant_change_in_Amps,
            significant_change_in_mm):
        
        """
        Analyzes the raw realtime cycle data and compares against the arguments given, placing it in appropriate 
        data structures if necessary

            Args:
                realtime_dataframe (pandas dataframe): The dataframe of the entire realtime data csv file 
                cols (list): the list of columns in the realtime dataframe
                row_index_of_cycle (int): the row index of the cycles' data in the realtime dataframe 
                application_id (int): the application id of the cycle recorded from the file 

                See _load_sequential_file() docstring for remaining args 

            Returns: 
                tuple (start_index, stats, corrected_data{}, significant_changes{}. out_of_bounds{})

                see _load_realtime_file() for realtime_metadata definition. 1 element in the realtime_metadata list 
                is what this function returns

        """

        start = tm.time()

        raw_cycle_data, _ = DataProcessor._get_realtime_cycle_from_dataframe(realtime_dataframe, start_index, next_start_index)


        #cols = list of column headers
        num_of_cols = len(cols)
       
       
        #variable amounts of these values, so storing in dicts for faster access
        #keep in mind these dicts are specific for the cycle data provided to this function 
        corrected_data = {}
        significant_changes = {}
        out_of_bounds = {}
        stats = {}

      
        #process for each column
        for col in range(num_of_cols):
            header = cols[col]

            
            #put headers of data you don't want to process here 
            if not (header == 'ApplicationId') and not (header == "Calculated  CRC"):


                column_data = raw_cycle_data[:,col]
                corrected_column_data = column_data.copy()

                num_of_rows = len(column_data)

                if(num_of_rows < 1):
                    print("zero rows")

                #list for all changes between values in col
                significant_changes_check = np.empty(num_of_rows-1)

                #boolean list if values in col are outside the bounds set in args 
                out_of_bounds_check = np.zeros(num_of_rows, dtype=bool)
                
                #list of differences between the adjacent values in the col (is size len(col) - 1)
                diffs = np.diff(column_data)
                
                if header.strip() == "Pressure (PSI)":
                    
                    out_of_bounds_check = (column_data < pressure_bound_low) | (column_data > pressure_bound_high)

                    significant_changes_check = np.abs(diffs) > significant_change_in_PSI
                

                elif header == "Standard Current (A)":
                    
                    out_of_bounds_check = (column_data < current_bound_low) | (column_data > current_bound_high)

                    significant_changes_check = np.abs(diffs) > significant_change_in_Amps

                elif header.strip() == "Cycle Distance (mm)":

                    out_of_bounds_check = (column_data < distance_bound_low) | (column_data > distance_bound_high)
                    
                    significant_changes_check = np.abs(diffs) > significant_change_in_mm

                #down here is where you get the new stats, maybe get old stats above? (unsure)

                for row in range(num_of_rows):
                    
                    #Significant changes length based on diffs length, which is of length num_of_rows - 1 
                    if (row < (num_of_rows - 1)) and significant_changes_check[row]:
                        
                        #row is actually the index here, same with col, want to provide dict with non-indexed locators
                        significant_changes[(col + 1, row + 1)] = True
                    
                    #if there is an out of bounds value, fix and add to corrected data dict
                    if out_of_bounds_check[row]:
                        #average based on previous data in the cycle, up to 10 previous values
                        if row < 10:
                            if row > 0:
                                #average from last n values in cycle if < 10 rows in 
                                corrected_datapoint = int(round(np.mean(column_data[0:row])))
                            else: #row == 0
                                # take value of cycle in front of it, otherwise just keep as error value in the 
                                #case there is only one value in the cycle is out of bounds (highly unlikely)
                                if row < (num_of_rows - 1):
                                    corrected_datapoint = column_data[row+1]
                                else:
                                    corrected_datapoint = column_data[0]

                        #average from the last 10 vlaues in the cycle if more than 10 points in cycle            
                        else: 
                            corrected_datapoint = int(round(np.mean(column_data[row-10:row])))
                            
                        corrected_column_data[row] = corrected_datapoint
                        corrected_data[(col + 1, row + 1)] = corrected_datapoint

                        #Col name, row index in column_data : value
                        out_of_bounds[(col + 1 ,row + 1)] = column_data[row]
                        

                #stats are based on corrected data 
                weight = num_of_rows
                min = int(np.min(corrected_column_data))
                max = int(np.max(corrected_column_data))
                average = round(np.mean(corrected_column_data), 1)

                
                stats_tuple = weight, min, max, average

                stats[(col + 1)] = stats_tuple

                #Do any more data processing or analysis here 

        time = tm.time() - start
        timems = time * 1000
        print(f"Time to process application id {application_id}: {timems} ms")
        
        return start_index, stats, corrected_data, significant_changes, out_of_bounds, 



    @staticmethod
    def _load_realtime_file(csv_file,  
                            current_bound_low,
                            current_bound_high,
                            significant_change_in_Amps,
                            pressure_bound_low,
                            pressure_bound_high,
                            significant_change_in_PSI,
                            distance_bound_low,
                            distance_bound_high,
                            significant_change_in_mm):
        
        """
        See _load_sequential_file() description

        Args: 
            csv_file - realtime data csv file
            See _load_sequential_file() args list for remaining args 
        
        Returns: 
            realtime_dataframe (pandas dataframe): the dataframe representation of the realtime data csv file

            realtime_metadata (list): a list of information for each realtime cycle

            Ex. realtime_metadata[0] = (start_index, {dict1}, {dict2}, {dict3}, {dict4})

            start_index - the index that the cycle data starts at in the realtime_dataframe

            dict 1 - stats: { int[column that the stats are based on] : tuple(weight, min, max, avg)] 
            Ex. stats[3] = 16, -11, 450, 15.6 means
            within   application id n, for the 3rd column in the file provided, there were 16 samples, -11 was the min, 
            450 was the max, and the average was 15.6 

            dict 2 - corrected_data: { (column, row) : corrected_data }
            Ex.  corrected_data[(2, 7)] = 400 means
            within application id n, for the 2nd column of the 7th row in that cycle in the file provided, 
            the datapoint was out of the bounds set and corrected to a value of 400

            dict 3 - significant_changes: { (column, row) : [bool]} 
            Ex. significant_changes[(5,8)] = True 
            within application id n, for the 5th column of the 8th row in application id n the difference 
            of values between row 8 and row 9 (8 + 1) exceeded the significant_change_in_(..) argumnet 

            dict 4 - out_of_bounds: { (column, row) : number}
            Ex. out_of_bounds[(3, 1)] = 579 
            within application id n, for the 3rd column of the 1st row in application id n the datapoint (579) was outside of the 
            bounds set in the (..)_bound_low or (..)_bound_high argument
            
            NOTE: all columns and rows are NOT indexed. they are normal.
            meaning column 1 is the first column and row 1 is the first row. column labels/headers are not included in the metadata

            TODO for improvements
            - pull the data typing parameters from quick link website itself would be cool 
        """

        print("Load realtime")

        start_processing_file = tm.time()

        #get headers in a list, strip the strings for accuracy
        actual_headers = [h.strip() for h in pd.read_csv(csv_file, nrows=0).columns.tolist()]

        #Trimming down size when possible by forcing entries into smaller datatypes using this map
        #Headers commented out assumed to be 64 bit ints (pandas deataframe default)
        all_realtime_dtype_map = {
            "ApplicationId" :       np.uint32,
            "Pressure (PSI)" :      np.int16,
            "Standard Current (A)" :np.int16,
            "Current (mA)" :        np.int32,
            "Cycle Distance (um)" : np.uint32,
            # Calculated CRC
        }

        #trims down the dtype map to only the headers that were provided in the realtime file from the user 
        safe_realtime_dtype_map = {col: dtype for col, dtype in all_realtime_dtype_map.items() if col in actual_headers}

        #read the csv file using the dtype and converter map, convert as you read
        realtime_dataframe = pd.read_csv(csv_file, dtype=safe_realtime_dtype_map)

        #get list of columns
        realtime_dataframe.columns = realtime_dataframe.columns.str.strip()

        #converting milliamp to amp values, makes plot easier to read
        if 'Current (mA)' in realtime_dataframe.columns:
            realtime_dataframe['Current (mA)'] = realtime_dataframe['Current (mA)'] / 1000

        realtime_dataframe.rename(columns={'Current (mA)' : 'Standard Current (A)'}, inplace=True)

        #convertin micrometer to milimeter values, makes plot easier to read 
        if 'Cycle Distance (um)' in realtime_dataframe.columns:
            realtime_dataframe['Cycle Distance (um)'] = realtime_dataframe['Cycle Distance (um)'] / 1000
        
        #rename the columns 
        realtime_dataframe.rename(columns={'Cycle Distance (um)' : 'Cycle Distance (mm)'}, inplace=True)

        #get column header strings in list to pass to _process() function
        cols = realtime_dataframe.columns.tolist()

        Application_Ids = realtime_dataframe['ApplicationId']

        change_mask = Application_Ids != Application_Ids.shift(1)
        start_indices = change_mask[change_mask].index.tolist()

        #first application id will be missed, manually put in
        if 0 not in start_indices:
            start_indices = [0] + start_indices

        actual_num_of_cycles = len(start_indices)

        batch_size = DataProcessor.REALTIME_BATCH_SIZE 

        for batch_start, batch_end in DataProcessor.batch_cycle_nums(actual_num_of_cycles, batch_size):
            print(f"Batch cycles from {batch_start} to {batch_end - 1} (size {batch_end - batch_start})")

        #generate args list
        realtime_args = [
            (
                realtime_dataframe,
                cols,
                Application_Ids.iloc[start_indices[cycle_index]], #cycle num
                start_idx, # start of that cycle num in the dataframe 
                cycle_length_in_rows,
                pressure_bound_low,
                pressure_bound_high,
                current_bound_low,
                current_bound_high,
                distance_bound_low,
                distance_bound_high,
                significant_change_in_PSI,
                significant_change_in_Amps,
                significant_change_in_mm
            )

            for cycle_index, (start_idx, cycle_length_in_rows) in enumerate(zip(start_indices, start_indices[1:] + [len(realtime_dataframe)]))
        ]

        #put args tuples into batches for multiprocessing
        args_batches = list(DataProcessor.batch_cycle_args(realtime_args, batch_size))

        #Multiprocessing
        with Pool(cpu_count()) as pool:
            batch_results = pool.map(DataProcessor._process_realtime_cycle_batch, args_batches)

        #flattened list of all the results of a cycle. each element contains the cycle num and 4 dicts return that each cycle returns
        realtime_metadata = [item for sublist in batch_results for item in sublist]

        print(f"Elapsed processing time for whole file: {tm.time() - start_processing_file:.2f} sec")

        return realtime_dataframe, realtime_metadata, 
    















    # ============================== INSTANCE FUNCTIONS ========================


    def _is_sequential_file(self, file):

        """
        Checks if the file has an applicaiton id column. If not, cannot parse. If there is, 
        it checks all the cases where an application id matches the one in the next row. If this 
        happens more than x times (number set by you, the editor), the file is not considered sequential 
        as a sequential file should have different app id's for each cycle, and each row should be a new cycle 
        (new applicaiton id)

        x = 50 in this function, may be changed

        Args: 
            file (string): path to the file 
        
        Returns: 
            boolean: true if < x consecutive app id's are matching, meaning each row represents a unique app id (cycle)
            false if there is no 'applicationid' column (case and space insensitive) or there are matching app id's
    
        """
        
        #get headers from user input realtime CSV into dataframe, put into list
        user_input_realtime_headers = pd.read_csv(file, nrows=0)
        user_headers = user_input_realtime_headers.columns.tolist()

        # if it has app id column, check if the anywhere in the file the app id is repeated, if there 
        # are more matching than the tolerance set (3), it is declareed as realtime
        has_app_id_column = any(col.strip().lower() == 'applicationid' for col in user_headers)

        if not has_app_id_column: 
            return False 
        
        prev_app_id = None
        total_matching_count = 1

        with open(file, newline='', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            
            for row in reader:
                current_app_id = row.get('ApplicationId', '').strip()

                if current_app_id == prev_app_id:
                    total_matching_count += 1
                    if total_matching_count > 50: #3 application id's can match, can change this tolerance 
                        return False

                prev_app_id = current_app_id

        if total_matching_count < 50:
            return True
        else:
            return False




    def _is_realtime_file(self, file): 

        """
        Checks if the file has an applicaiton id column. If not, cannot parse. If there is, 
        it checks all the cases where an application id matches the one in the next row. If this 
        happens more than x times (number set by you, the editor), the file is considered a realtime 
        as a realtime file very likelky has multiple recordings per cycle, with the same app id being reocrded if the data is gabbed more than once in 
        the same cycle 

        x = 3 in this function, may be changed

        Args: 
            file (string): path to the file 

        boolean: true if > x consecutive app id's are matching, meaning each row represents a unique app id (cycle)
            false if there is no 'applicationid' column (case and space insensitive) or there are matching app id's



        """

    
        #get headers from user input realtime CSV into dataframe, put into list
        user_input_realtime_headers = pd.read_csv(file, nrows=0)
        user_headers = user_input_realtime_headers.columns.tolist()

        # if it has app id column, check if the anywhere in the file the app id is repeated, we know it is realtime
        has_app_id_column = any(col.strip().lower() == 'applicationid' for col in user_headers)

        if not has_app_id_column: 
            return False 
        
        #if there are three times an app id value repeats itself in a consecutive line 
        #it is declared realtime becuase the app id's repeat
        #meaning multiple sampels taken per cycle/ per app id 
        total_matching_count = 0
        prev_app_id = None

        with open(file, newline='', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            
            for row in reader:
                current_app_id = row.get('ApplicationId', '').strip()

                if current_app_id == prev_app_id:
                    total_matching_count += 1
                    if total_matching_count > 3:
                        return True

                prev_app_id = current_app_id

          
            
        if total_matching_count < 3:
            return False
        else: 
            return True

        



    
    def check_files(self, file_list):
        """
        Checks whether the files in file_list are valid (either sequential or realtime).
        
        Args:
            file_list (list): A list containing the file paths

        Returns:
            python list of valid file info [filetype1, filepath 1, filetype2, filepath2]
            python list of invalid filepaths
        """
        valid_files = []
        invalid_files = []

        for file in file_list:
            
            if (self._is_sequential_file(file)):
                valid_files.append('s')
                valid_files.append(file)
            elif (self._is_realtime_file(file)):
                valid_files.append('r')
                valid_files.append(file)
            else:
                invalid_files.append(file)

        return valid_files, invalid_files



    

    def process_files(self, 
                    file_info,  
                    current_bound_low,
                    current_bound_high,
                    significant_change_in_Amps,
                    pressure_bound_low,
                    pressure_bound_high,
                    significant_change_in_PSI,
                    distance_bound_low,
                    distance_bound_high,
                    significant_change_in_mm):

        """
        loads the given file(s) in file_info with their appropraite _load function 
        and returns the dataframes and metadata lists of those files. Any file reading errors are printed 
        to the console
        
        Args: 
            file_info (list): list of files and filepaths [filetype1, filepath 1, filetype2, filepath2]

        returns: 
            tuple (valid_file_data, invalid_files)

            valid_file_data (list): [type1, filepath1, dataframe1, metadata1,  type2, filepath2, dataframe2, metadata2, ...)]

            invalid_files (list): list of files that could not be parsed due to corrupted/incorrect data 
        
        """
        valid_file_data = []
        invalid_files = []
        

        for i in range(0, len(file_info), 2):
            try:
                filetype = file_info[i]
                filepath = file_info[i+1]
                if filetype == 's':
                    new_dataframe, new_metadata= DataProcessor._load_sequential_file(filepath, 
                                                                                    current_bound_low,
                                                                                    current_bound_high,
                                                                                    significant_change_in_Amps,
                                                                                    pressure_bound_low,
                                                                                    pressure_bound_high,
                                                                                    significant_change_in_PSI,
                                                                                    distance_bound_low,
                                                                                    distance_bound_high,
                                                                                    significant_change_in_mm)
                else:
                    new_dataframe, new_metadata = DataProcessor._load_realtime_file(filepath,   
                                                                                    current_bound_low,
                                                                                    current_bound_high,
                                                                                    significant_change_in_Amps,
                                                                                    pressure_bound_low,
                                                                                    pressure_bound_high,
                                                                                    significant_change_in_PSI,
                                                                                    distance_bound_low,
                                                                                    distance_bound_high,
                                                                                    significant_change_in_mm)

                valid_file_data.append(filetype)
                valid_file_data.append(filepath)    
                valid_file_data.append(new_dataframe)
                valid_file_data.append(new_metadata)

            except FileNotFoundError:
                return  
            except Exception as e:
                invalid_files.append(filepath)
                print(f"Failed to load {filepath}: {e}")
                traceback.print_exc()
                            
        return valid_file_data, invalid_files