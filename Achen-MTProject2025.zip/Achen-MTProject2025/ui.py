"""
 ui.py

 The ui.py file is handed control of program flow from the main file.
 This file utilizes the Tkinter library for all of it's UI functionality 
 
 Begins with a window allowing users to select sequential and realtime data files 
 and 1 Realtime data file (both in CSV format), and a minimum of 1 CSV file 

 Then, utilizing the data_loader.py source file, generates a visualizer for 
 each of the CSV data files given. Within either a SequentialWindow or a RealtimeWindow, there are several 
 user options supported to manipulate the visualizer in the window 

 Both SequentialWindow and RealtimeWindow inherit from the BaseWindow class. This class 
 defines all the functionality that both windows have, to include: 

 BaseWindow: 
  - Select individual cycle to view (by number or application id)
  - Select cycle range to view (by number or application id)
  - zoom and pan on cycle graphs
  - pick which variables graph shows to user
  - Export all graphs/histograms 

 SequentialWindow: 
  - For the selected range of cycles 
  Select a trend view (graph) for the appropriate variables 
  in LUT definition sheet

 RealtimeWindow: 
  - Change the range bounds and significant change values and 
  reprocess the file with those values
  - Generate a CSV report of the realtime data for the provided range (corrected, out of bounds, etc)
 
  
 The bottom of the file contains all the intial window functionality
  - File selection box
  - CSV file uploading 
  - Initial ranges and changes entires 
  - Process button

 """
#project imports
from data_loader import DataProcessor
from visualizer import SequentialVisualizer, RealtimeVisualizer

#library imports 
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog, messagebox
import os 
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk


#Array for 2 files the user selects 
currently_selected_files = []


"""UI CLASSES BELOW"""



class BaseWindow:
    """PARENT CLASS FOR SEQUENTIAL + REALTIME WINDOWS

    Defines the basic Window Format for both windows
    using Tkinter tools. Both windows have a canvas for a graph, a toolbar, 
    and a cycle / app id entries and selection from to view the cycles in
    the file uploaded
    """

    #Constants for ranges and changes values (CAN BE CHANGED)
    #'Default Values' button
    DEFAULT_CURRENT_MIN_A = 0
    DEFAULT_CURRENT_MAX_A = 30
    DEFAULT_CURRENT_SIGNIFICANT_CHANGE_A = 5

    DEFAULT_PRESSURE_MIN_PSI = -100
    DEFAULT_PRESSURE_MAX_PSI = 10000
    DEFAULT_PRESSURE_SIGNIFICANT_CHANGE_PSI = 1000

    DEFAULT_DISTANCE_MIN_MM = 0
    DEFAULT_DISTANCE_MAX_MM = 60
    DEFAULT_DISTANCE_SIGNIFICANT_CHANGE_MM = 1

    #Constants for ranges and changes values (CAN BE CHANGED)
    #'Maximum Values' button
    LOWEST_CURRENT_MIN_A = -10
    HIGHEST_CURRENT_MAX_A = 150
    LARGEST_CURRENT_SIGNIFICANT_CHANGE_A = 160

    LOWEST_PRESSURE_MIN_PSI = -100
    HIGHEST_PRESSURE_MAX_PSI = 10000
    LARGEST_PRESSURE_SIGNIFICANT_CHANGE_PSI = 11000

    LOWEST_DISTANCE_MIN_MM = 0
    HIGHEST_DISTANCE_MAX_MM = 100
    LARGEST_DISTANCE_SIGNIFICANT_CHANGE_MM = 100


    def __init__(self, master, title, visualizer):
        """
        Constructor for the base window. Initializes the Tkinter window
        and creates the: 
        Plot frame
            - the canvas / plot (which is connected to the
            visualizer this window was provided) 
            - the toolbar beneath the plot 

        Checkbox frame
            - button(s) for viewing which variables 
            are shown in the window 

        Cycle view frame
            - two tabs for either viewing by the cycle number 
            or the application id
            - single cylce / app id viewing 
            - cycle range / app id viewing
            - string variables showing which cycle(s) / app id(s) are 
            currently displayed 
            - connects the entry validation commands (vcmd's)
            to their registered functions to prevent user misentry 

        Args: 
            master (tk window or root, etc.): The Tkinter window/ root that owns this window 

            title (string): the title of the window 

            visualizer (BaseVisualizer): the visualizer object connected to the plot 
            in the data
        """
        
        #intial creation
        self.visualizer = visualizer
        self.window = tk.Toplevel(master)
        self.window.title(title)
        self.window.geometry("1000x1000")
        
        #frame for the plot 
        self.plot_frame = tk.Frame(self.window)
        self.plot_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=10)

        #canvas wrapper holds canvas, canvas hold graph
        self.canvas_wrapper = tk.Frame(self.plot_frame)
        self.canvas_wrapper.pack(fill=tk.BOTH, expand=True)

        #canvas holds graph 
        self.canvas = FigureCanvasTkAgg(self.visualizer.get_figure(), master=self.canvas_wrapper)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.canvas.draw()

        #add toolbar for plotter 
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.plot_frame)
        self.toolbar.update()

        #used for checking which data you want to see
        self.checkbox_frame = tk.Frame(self.window)
        self.checkbox_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        #controls frame 
        self.controls_frame = tk.Frame(self.window)
        self.controls_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)

        # Group into a labeled frame for cycle controls
        self.cycle_frame = tk.LabelFrame(self.controls_frame, text="Cycle Controls")
        self.cycle_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

        #cycle controls tab selector 
        self.tab_selector_frame = tk.Frame(self.cycle_frame)
        self.tab_selector_frame.pack(fill='x')

        #switch between tabs 
        tk.Button(self.tab_selector_frame, text="View by Cycle", command=lambda: self.show_cycle_tab("cycle")).pack(side=tk.LEFT, padx=5)
        tk.Button(self.tab_selector_frame, text="View by Application ID", command=lambda: self.show_cycle_tab("app_id")).pack(side=tk.LEFT, padx=5)

        #validate command for integer entry only (cycle or app id entry )
        cycle_vcmd = self.window.register(self.validate_cycle)
        self.cycle_vcmd = (cycle_vcmd, '%P')
        
        #controls user input for vcmd. Doesn't allow missing app id's to be put in
        app_id_vcmd = self.window.register(self.validate_app_id)
        self.app_id_vcmd = (app_id_vcmd, '%P')

        #text boxes for cycle and app id labels on the side of the window 
        self.cycle_range_var = tk.StringVar()
        self.app_id_range_var = tk.StringVar()
        self.invalid_app_id_var = tk.StringVar()
        
        #2 inner frames for the tabs 
        self.cycle_tab_cycle = self.create_cycle_tab_cycle()
        self.cycle_tab_app_id = self.create_cycle_tab_app_id()

        #cycle view tab a
        self.current_cycle_tab = None
        self.show_cycle_tab("cycle") 


    def update_plot_visibility(self, *cycles):
        """
        Updates the visualizer and the plot owned by the BaseWindow. Records the user options 
        from the entries and buttons in the checkbutton frame in accordance with the button they clicked that called this, 
        and updates the window plot to show what the user (button) requested 

        Args: 
            *cycles (list): if len(cycles) == 1 there is a single cycle to be shown 
                            if len(cycles) == 2 there is a range of cycles to be shown
        """

       
        if isinstance(self.visualizer, SequentialVisualizer):

            trend_var = self.selected_trend.get()

            #TODO: get variable from the sequential dropdown, send to be plotted on trend 
            if len(cycles) == 1:
                self.visualizer.set_cycle_num(cycles[0])
                self.visualizer.show_current_cycle_num(trend_var)
                self.canvas.draw()

            elif len(cycles) == 2:
                self.visualizer.set_cycle_range(cycles[0], cycles[1])
                self.visualizer.show_curent_cycle_range(trend_var)
                self.canvas.draw()
            


        elif isinstance(self.visualizer, RealtimeVisualizer):
            args_to_plot = []

            pressure_checked = self.show_pressure_var.get()
            current_checked = self.show_current_var.get()
            distance_checked = self.show_distance_var.get()

            if pressure_checked:
                args_to_plot.append(self.visualizer.pressure_label)
            if current_checked:
                args_to_plot.append(self.visualizer.current_label)
            if distance_checked:
                args_to_plot.append(self.visualizer.distance_label)

            if len(cycles) == 1:
                self.visualizer.set_cycle_num(cycles[0])
                self.visualizer.show_current_cycle_num(*args_to_plot)
            elif len(cycles) == 2:
                self.visualizer.set_cycle_range(cycles[0], cycles[1])
                self.visualizer.show_current_cycle_range(*args_to_plot)
            
            self.canvas.draw()

       





    def validate_cycle(self, value_if_allowed):
        """
        User input validation function: allow only integers between 1 and the 
        visualizer's total number of cycles (the visualizer being the 
        one provided in BaseWindow constructor where these functions are used)

        Args: 
            value_if_allowed: can be either an empty string (meaning the user clicked 
            on the entry and hasn't entered anything yet)
            or can be a numerical, non floating point string. If the numerical value 
            of the string is > visualizers total number of cycles, it will not be allowed to be typed 
            (i.e. 30 total cycles, I type "3" can that is acceptable but I try to type a "1" directly 
            following my three, and the entry box will not repsond or put the "1" next to "3")

        Returns: 
            boolean: True if the string numerical value is acceptable within the vcmd, 
            False if not
        """
        if value_if_allowed == "":
            return True  # allow empty for editing
        try:
            val = int(value_if_allowed)
            max_val = int(self.visualizer.total_cycles)
            return 1 <= val <= max_val
        except ValueError:
            #Does not respond to blank input
            return False
        
    def validate_app_id(self, value_if_allowed):
        """
        User input validation function: allow only integers between 1 and the 
        visualizer's largest app id that are NOT listed in the 
        visualizer's missing app id list. (the visualizer being the 
        one provided in BaseWindow constructor where these functions are used)

        Args: 
            See validate_cycle() above. Additionally, if the value you type 
            is in the visualizer's missing app id's list, you will not be 
            allowed to type it and the entry box will not respond

        Returns: 
            boolean: True if the string numerical value is acceptable within the vcmd, 
            False if not
        """
        
        if value_if_allowed == "":
            return True # allow empty for editing
        try: 
            val = int(value_if_allowed)
            max_val = int(self.visualizer.max_app_id)
            self.invalid_app_id_var.set("")
            if val in self.visualizer.missing_ids:
                #label right below app id entry saying can't enter it
                self.invalid_app_id_var.set(f"ID {val} not found in data")
                return False
            return 1 <= val <= max_val
        except ValueError:
            #Does not respond to blank input
            return False
            
                
    def create_cycle_tab_cycle(self):
        """
        Creates the cycle entry labels and show single cycle and 
        show cycle range buttons within the "View by Cycle" tab 
        using the Tkinter grid layout. Sets the UI elements to tell the 
        user it is currently showing cycle 1, displays total cycles and min and max app id
        """
        frame = tk.Frame(self.cycle_frame)
        
        #row 0: single cycle / application id view selection and entry
        tk.Label(frame, text="Cycle #:").grid(row=0, column=0, padx=5, pady=5, sticky='e')
        self.cycle_num_entry = tk.Entry(frame, width=7, validate='key', validatecommand=self.cycle_vcmd)
        self.cycle_num_entry.grid(row=0, column=1, padx=2, pady=5)
        self.cycle_num_entry.delete(0, tk.END)
        self.cycle_num_entry.insert(0, "1")

        self.submit_cycle_num_button = tk.Button(
            frame, text="Show Single Cycle", command=self.handle_cycle_num_submit,
            bg='green',
            fg='white',
            activebackground='green',
            activeforeground='white',
            disabledforeground='gray'
        )
        self.submit_cycle_num_button.grid(row=0, column=6, padx=10, pady=5)

        #row 0: "showing cycle: x" label
        self.cycle_range_var.set(f"Now Showing Cycle: 1    Max: {self.visualizer.total_cycles}")
        self.cycle_range_label = tk.Label(
        frame,
        textvariable=self.cycle_range_var,
        anchor='e',
        justify='right')
        self.cycle_range_label.grid(row=0, column=8, padx=10, pady=5, sticky='e')

        #row 1: cycle / application id range view selection and entry 
        tk.Label(frame, text="Cycle Min:").grid(row=1, column=0, padx=5, pady=5, sticky='e')
        self.cycle_min_entry = tk.Entry(frame, width=7, validate='key', validatecommand=self.cycle_vcmd)
        self.cycle_min_entry.grid(row=1, column=1, padx=2, pady=5)

        tk.Label(frame, text="Max:").grid(row=1, column=2, padx=5, pady=5, sticky='e')
        self.cycle_max_entry = tk.Entry(frame, width=7, validate='key', validatecommand=self.cycle_vcmd)
        self.cycle_max_entry.grid(row=1, column=3, padx=2, pady=5)

        self.submit_cycle_range_button = tk.Button(
            frame, text="Show Cycle Range", command=self.handle_cycle_range_submit,
            bg='green',
            fg='white',
            activebackground='green',
            activeforeground='white',
            disabledforeground='gray'
        )
        self.submit_cycle_range_button.grid(row=1, column=6, padx=10, pady=5)

        
        #row 1: "showing app id x" label
        #index of cycle app id is first element of the tuple of each element in the metadata list
        self.app_id_range_var.set(f"Now Showing Application ID: {int(self.visualizer.dataframe.iloc[0]['ApplicationId'])}     Max: {int(self.visualizer.max_app_id)}")
        self.app_id_range_label = tk.Label(
        frame,
        textvariable=self.app_id_range_var,
        anchor='e',
        justify='right')
        self.app_id_range_label.grid(row=1, column=8, padx=10, pady=5, sticky='e')

        #make column 6 align to R of window always
        frame.grid_columnconfigure(8, weight=1)

        #Button to sync cycles between windows (only works with 2 windows)
        #self.update_sync_button()

        return frame
    

    def create_cycle_tab_app_id(self):
        """
        Creates the app id entry labels and show single app id and 
        show apop id range buttons within the "View by Cycle" tab 
        using the Tkinter grid layout. Sets the UI elements to tell the 
        user it is currently showing cycle 1, the app id for cycle 1, 
        and displays total cycles and min and max app id
        """

        frame = tk.Frame(self.cycle_frame)

        #row 0: single cycle / application id view selection and entry
        tk.Label(frame, text="Application ID:").grid(row=0, column=0, padx=5, pady=5, sticky='e')
        self.app_id_num_entry = tk.Entry(frame, width=7, validate='key', validatecommand=self.app_id_vcmd)
        self.app_id_num_entry.grid(row=0, column=1, padx=2, pady=5)
        self.app_id_num_entry.delete(0, tk.END)
        first_appid = self.visualizer.dataframe.loc[0, 'ApplicationId']
        self.app_id_num_entry.insert(0, str(first_appid))

        self.submit_app_id_num_button = tk.Button(
            frame, text="Show Single Application ID", command=self.handle_app_id_num_submit,
             bg='green',
            fg='white',
            activebackground='green',
            activeforeground='white',
            disabledforeground='gray'
        )
        self.submit_app_id_num_button.grid(row=0, column=4, padx=10, pady=5)

        self.invalid_app_id_var.set("")
        self.invalid_app_id = tk.Label(
        frame,
        textvariable=self.invalid_app_id_var,
        anchor='e',
        justify='right',
        font=('Arial', 10),
        fg='red'
        )
        self.invalid_app_id.grid(row=0, column=3, padx=2, pady=5)

        #row 0: "showing cycle: x" label
        self.cycle_range_var.set(f"Now Showing Cycle: 1    Max: {self.visualizer.total_cycles}")
        self.cycle_range_label = tk.Label(
        frame,
        textvariable=self.cycle_range_var,
        anchor='e',
        justify='right')
        self.cycle_range_label.grid(row=0, column=8, padx=10, pady=5, sticky='e')


        #row 1: cycle / application id range view selection and entry 
        tk.Label(frame, text="Application ID Min:").grid(row=1, column=0, padx=5, pady=5, sticky='e')
        self.app_id_min_entry = tk.Entry(frame, width=7, validate='key', validatecommand=self.app_id_vcmd)
        self.app_id_min_entry.grid(row=1, column=1, padx=2, pady=5)

        tk.Label(frame, text="Max:").grid(row=1, column=2, padx=5, pady=5, sticky='e')
        self.app_id_max_entry = tk.Entry(frame, width=7, validate='key', validatecommand=self.app_id_vcmd)
        self.app_id_max_entry.grid(row=1, column=3, padx=2, pady=5)

        self.submit_app_id_range_button = tk.Button(
            frame, text="Show Application ID Range", command=self.handle_app_id_range_submit,
            bg='green',
            fg='white',
            activebackground='green',
            activeforeground='white',
            disabledforeground='gray'
        )
        self.submit_app_id_range_button.grid(row=1, column=4, padx=10, pady=5)

        
        #row 1: "showing app id x" label
        #index of cycle app id is first element of the tuple of each element in the metadata list
        self.app_id_range_var.set(f"Now Showing Application ID: {int(self.visualizer.dataframe.iloc[0]['ApplicationId'])}     Max: {int(self.visualizer.max_app_id)}")
        self.app_id_range_label = tk.Label(
        frame,
        textvariable=self.app_id_range_var,
        anchor='e',
        justify='right')
        self.app_id_range_label.grid(row=1, column=8, padx=10, pady=5, sticky='e')

        #make column 7 align to R of window always
        frame.grid_columnconfigure(8, weight=1)

        return frame
    


    #-----BUTTON HANDLER DEFINITIONS----------------


    #lambda function to switch between tabs 
    def show_cycle_tab(self, tab):
        """
        shows either the view by cycle or view by app id 
        
        Args:
            tab (string): the type of tab (show by cycle or show by app id)
            to show in the cycle controls frame 
        """
        if self.current_cycle_tab is not None:
            self.current_cycle_tab.pack_forget()

        if tab == "cycle":
            self.current_cycle_tab = self.cycle_tab_cycle
        elif tab == "app_id":
            self.current_cycle_tab = self.cycle_tab_app_id

        self.current_cycle_tab.pack(fill='x')


    #num already validated by vcmd above 
    def handle_cycle_num_submit(self, cycle_arg=None):
        """
        grabs the number in the single cycle entry field,
        and updates the plot in the window to show that cycle
        as well as the entry boxes  
        (number in field is validated by the vcmd's above)

        Args:
            cyce_arg=None (string): if provided, the cycle arg
            will be either an empty or numerical, non floating 
            point string
        """

        if cycle_arg is None:
            cycle_arg = self.cycle_num_entry.get()

        if (cycle_arg != ''):
           cycle = int(cycle_arg)
           self.update_plot_visibility(cycle)
           self.update_cycle_and_app_labels(cycle)


    def handle_app_id_num_submit(self):
        """
        Gets the app id from the entry field,
        converts it to it's cycle num using the visualizer 
        that this button's parent window owns, and 
        provides it to handle_cycle_num_submit()
        """
      

        app_id_entry  = self.app_id_num_entry.get()

        if (app_id_entry != ''):
            app_id = int(app_id_entry)

            cycle = self.visualizer.app_id_to_cycle(app_id)
            self.handle_cycle_num_submit(cycle)

    
    #num validated, logic is range specific
    def handle_cycle_range_submit(self, *args):
        """
        Grabs the cycle min and max numbers in the cycle range entry fields 
        or from the *args list if provided and updates the plot in the 
        window to show that cycle range as well as the cycle range 
        entry boxes
        (numbers in fields are validated by the vcmd's above)

        Args:
            *args (list): a int list of the cycle range numbers [min, max]
            or an empty list

        Returns: 
            boolean: True if the cycle range provided or in the 
            fields is valid and the plot is updated
            False if the cycle range is invalid or not provided in 
            the args and the entry fields
        """

        if not args:
            cycle_min_entry = self.cycle_min_entry.get()
            cycle_max_entry = self.cycle_max_entry.get()

        else: 
            cycle_min_entry = args[0]
            cycle_max_entry = args[1]
        
        if (cycle_min_entry != '' and cycle_max_entry != ''):  

            cycle_min = int(cycle_min_entry)
            cycle_max = int(cycle_max_entry)

            #if same val in min and max fields, OK to just show that cycle
            if cycle_min < cycle_max:
                # sets the min and max cycle range attributes of the visualizer that belongs to this window 
                self.update_plot_visibility(cycle_min, cycle_max)
                self.update_cycle_and_app_labels(cycle_min, cycle_max)
                return True

            elif cycle_min == cycle_max:
                self.update_plot_visibility(cycle_min)
                self.update_cycle_and_app_labels(cycle_min)
                return True 

            else:
                messagebox.showinfo("User Input Error", "Cycle range low must be <= cycle range high.")
                return False
        return False
    
    
    def handle_app_id_range_submit(self):
        """
        Gets the min and max app id entries from the app id 
        range entry fields, converts to the cycle number each
        app id is in the data, and provides it to
        handle_cycle_range_submit()
        (numbers are vlaidated from the vcmd's above)

        Returns: same return as handle_cycle_range_submit()
        """
        app_id_min_entry = self.app_id_min_entry.get()
        app_id_max_entry = self.app_id_max_entry.get()

        if (app_id_min_entry != '' and app_id_max_entry != ''):

            app_id_min = int(app_id_min_entry)
            app_id_max = int(app_id_max_entry)

            cycle_min = self.visualizer.app_id_to_cycle(app_id_min)
            cycle_max = self.visualizer.app_id_to_cycle(app_id_max)

            self.handle_cycle_range_submit(cycle_min, cycle_max)

        



    def update_cycle_and_app_labels(self, *args):
        """
        Updates the string labels on the right side of the window 
        in accordance with the cycle number(s) given in args and the  
        total cycles and max app id of visualizer that belongs to this BaseWindow instance

        Args: 
            *args (list): if args is a single number, the labels will say 
            "showing cycle __"
            if args is two numbers, the labels are updated to "showing cycle __ to __"
        """
        
        if isinstance(self.visualizer, SequentialVisualizer):
        
            self.write_cycle_and_app_labels("sequential", *args)
            
        elif isinstance(self.visualizer, RealtimeVisualizer):

            self.write_cycle_and_app_labels("realtime", *args)

    
    def write_cycle_and_app_labels(self, type_of_visualizer, *args):
        if len(args) == 1:
            cycle = args[0]
            self.cycle_range_var.set(f"Now Showing Cycle: {cycle}     Max: {self.visualizer.total_cycles}")

            app_id_index = cycle - 1 if type_of_visualizer == "sequential" else self.visualizer.metadata[cycle - 1][0]
            app_id = self.visualizer.dataframe.iloc[app_id_index]['ApplicationId']
            self.app_id_range_var.set(f"Now Showing Application ID: {int(app_id)}     Max: {int(self.visualizer.max_app_id)}")


        elif len(args) == 2:
            cycle_one = args[0]
            cycle_two = args[1]
            self.cycle_range_var.set(f"Now Showing Cycle: {cycle_one} to {cycle_two}     Max:  {self.visualizer.total_cycles}")

            app_id_index_one = cycle_one - 1 if type_of_visualizer == "sequential" else self.visualizer.metadata[cycle_one - 1][0]
            app_id_index_two  = cycle_one - 1 if type_of_visualizer == "sequential" else self.visualizer.metadata[cycle_two - 1][0]
            app_id_one = self.visualizer.dataframe.iloc[app_id_index_one]['ApplicationId']
            app_id_two = self.visualizer.dataframe.iloc[app_id_index_two]['ApplicationId']
            self.app_id_range_var.set(f"Now Showing Applicaiton ID: {int(app_id_one)} to {int(app_id_two)}     Max: {int(self.visualizer.max_app_id)}")

        

       


    def set_cycle_range_entry_boxes(self, min, max):
        """
        Updates the respective cycle range entry fields with the
        min and max values as appropriate 
        """

        #clear the range entry boxes 
        self.cycle_min_entry.delete(0, tk.END)
        self.cycle_max_entry.delete(0, tk.END)

        #write string reps. of numbers to entry boxes
        self.cycle_min_entry.insert(0, str(min))
        self.cycle_max_entry.insert(0, str(max))


    def set_app_id_range_entry_boxes(self, min, max):
        """
        Updates the respective app id range entry fields with the
        min and max values as appropriate 
        """

        #clear the range entry boxes
        self.app_id_min_entry.delete(0, tk.END)
        self.app_id_max_entry.delete(0, tk.END)

        #write string reps. of numbers to entry boxes
        self.app_id_min_entry.insert(0, str(min))
        self.app_id_max_entry.insert(0, str(max))

    

    
    def handle_report_button_all(self):
        """
        Opens a file dailog for a user to name, place, and save 
        the CSV file of the report of relatime data for their 
        set ranges and changes. Writes the report to the new CSV, 
        and either informs the user of success and where to open the file 
        or warns the user if an error occurred while writing the 
        report or saving the file 
        """

        #generate csv, return 
        file_path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV files", "*.csv")],
        title="Save Application IDs CSV file")

        try:
            self.visualizer.write_report(file_path)
            print("Report Saved")
            self.show_custom_success_dialog(file_path)
        except Exception as e:
            messagebox.showerror("File Save Error", f"An unexpected error occurred trying to save the file {e}")

            

    def show_custom_success_dialog(self, path):
        """
        Opens a window informing the user the CSV report 
        of realtime data was successfully written and where it was saved, 
        as well as offers a button to open the file directly or close the window

        Args: 
            path (string): string representation of the file path of the CSV report
        """

        top = tk.Toplevel()
        top.title("Report Saved")

        tk.Label(top, text=f"Report saved to:\n{path}", wraplength=400, justify="left").pack(padx=20, pady=10)

        def open_file():
            os.startfile(path) 

        tk.Button(top, text="Open File", command=open_file).pack(pady=(0, 10))
        tk.Button(top, text="Close", command=top.destroy).pack()







    @staticmethod
    def reactivate_button(button):
        """
        Turns a buttons state to active visually cues the user it is ready
        (as opposed from the gray color and disables state when pushed)

        Args: 
            button (tkinter Button): the button to be reactivated 
        """
        if button is not None:
            button.config(state="active")
            button.config(bg='green',  fg="white", activebackground='green')

    @staticmethod 
    def disable_button(button):
        """
        Turns a buttons state to disabled and visually cues the user it not useable
        (as opposed from the green color and white text when ready to be used)

        Args: 
            button (tkinter Button): the button to be reactivated 
        """
        #this call will automatically make the button gray
        button.config(state="disabled")


    @staticmethod
    def try_ranges_and_changes(frame_elements_tuple, visualizer, canvas, showing_cycle_range_tk_var, showing_app_id_range_tk_var, 
                               pressure_checkbox, current_checkbox, distance_checkbox):
        """
        Gets the new range inputs from the frame_elements_tuple, checks them, and then 
        processes the file connected to the visualizer using those new ranges and changes values. 
        When complete, updates the UI and displays and first cycle 
        in the canvas provided

        Args: 
            see show_range_input_frame() args 
        """

        ranges_and_changes = BaseWindow.get_ranges_and_changes(frame_elements_tuple)

        if visualizer is not None and visualizer.ranges_and_changes_tuple == ranges_and_changes:
            messagebox.showwarning("Same inputs", "File will not be reprocessed unless values are changed.")
            return None
        
        #re process the file

        #update the metadata, and the graphs and the tuple 
        _, new_metadata = DataProcessor._load_realtime_file(visualizer.filepath, *ranges_and_changes)
        visualizer.metadata = new_metadata
        visualizer.ranges_and_changes_tuple = ranges_and_changes

        args_to_plot = []

        if pressure_checkbox is not None and current_checkbox is not None and distance_checkbox is not None: 
            
            if pressure_checkbox.get():
                args_to_plot.append(visualizer.pressure_label)
            if current_checkbox.get():
                args_to_plot.append(visualizer.current_label)
            if distance_checkbox.get():
                args_to_plot.append(visualizer.distance_label)


        if showing_cycle_range_tk_var is not None and showing_app_id_range_tk_var is not None:
              
              text = showing_cycle_range_tk_var.get()
              parts = text.split()


              if "to" in text:
                  #konw its a range, get and set
                  to_index = parts.index("to")
                  cycle_min = int(parts[to_index - 1])
                  cycle_max = int(parts[to_index + 1])

                  visualizer.set_cycle_range(cycle_min, cycle_max)
                  visualizer.show_current_cycle_range(*args_to_plot)


              else: 
                  #know it's a single cycle, get and set
                  cycle_colon_index = parts.index("Cycle:")
                  cycle = int(parts[cycle_colon_index + 1])

                  visualizer.set_cycle_num(cycle)
                  visualizer.show_current_cycle_num(*args_to_plot)

        else: 
            visualizer.set_cycle_num(1)
            visualizer.show_current_cycle_num(*args_to_plot)
            
        canvas.draw()
       




    @staticmethod
    def get_ranges_and_changes(range_frame_elements_tuple):
        """
        Checks all the user numerical inputs in the range_frame_elements_tuple, 
        ensures they make sense, and returns the tuple

        Args:
            range_frame_elements_tuple (tuple of tkinter entry fields, 9 elements): the entries for 
            the ranges and changes inputs in the range input frame 
        
        Returns: 
            the same range elements tuple in the args if the values are good 
            or a tuple of 9 'None' elements 
        
        """

        (
            current_min_entry,
            current_max_entry,
            current_significant_entry,
            pressure_min_entry,
            pressure_max_entry,
            pressure_significant_entry,
            cycle_distance_min_entry,
            cycle_distance_max_entry,
            cycle_distance_significant_entry,
            _,
            _,
            _,
        ) = range_frame_elements_tuple

       

        bad_return = None, None, None, None, None, None, None, None, None

        current_min, current_max = BaseWindow.handle_variable_range_submit(current_min_entry, current_max_entry, "Current range")
        if current_min is None:
            return bad_return
        
        current_change  = BaseWindow.handle_variable_change_submit(current_significant_entry, "Significant current change")
        if current_change is None: 
            return bad_return

        pressure_min, pressure_max = BaseWindow.handle_variable_range_submit(pressure_min_entry, pressure_max_entry, "Pressure range")
        if pressure_min is None:
            return bad_return
        
        pressure_change  = BaseWindow.handle_variable_change_submit(pressure_significant_entry, "Significant pressure change")
        if pressure_change is None: 
            return bad_return
        
        cycle_distance_min, cycle_distance_max = BaseWindow.handle_variable_range_submit(cycle_distance_min_entry, cycle_distance_max_entry, "Cycle Distance range")
        if cycle_distance_min is None:
            return bad_return
        
        distance_change = BaseWindow.handle_variable_change_submit(cycle_distance_significant_entry, "Significant Cycle Distance Change")
        if distance_change is None: 
            return bad_return
       

        return current_min, current_max, current_change, pressure_min, pressure_max,  pressure_change, cycle_distance_min, cycle_distance_max, distance_change

    @staticmethod
    def fill_ranges_and_changes(range_frame_elements_tuple, ranges_and_changes_value_tuple):
        """
        Fills the tkinter entries with the values provided for the user to see in the UI 

        Args: 
            range_frame_elements_tuple (tuple of tkinter entry fields, 9 elements): the entry fields for 
            the ranges and changes inputs in the range input frame 

            ranges_and_changes_value_tuple (tuple of 9 floats): the values corresponding 
            (in order_ to their respective range or change entry field
        """
            
        (
            current_min_entry,
            current_max_entry,
            current_significant_entry,
            pressure_min_entry,
            pressure_max_entry,
            pressure_significant_entry,
            cycle_distance_min_entry,
            cycle_distance_max_entry,
            cycle_distance_significant_entry
        ) = range_frame_elements_tuple
            
        (
            cmin, 
            cmax, 
            cchange, 
            pmin, 
            pmax, 
            pchange, 
            dmin, 
            dmax, 
            dchange,
         ) = ranges_and_changes_value_tuple

        current_min_entry.delete(0, tk.END)
        current_max_entry.delete(0, tk.END)
        current_min_entry.insert(0, str(cmin))
        current_max_entry.insert(0, str(cmax))
        current_significant_entry.delete(0, tk.END)
        current_significant_entry.insert(0, str(cchange))

        pressure_min_entry.delete(0, tk.END)
        pressure_max_entry.delete(0, tk.END)
        pressure_min_entry.insert(0, str(pmin))
        pressure_max_entry.insert(0, str(pmax))
        pressure_significant_entry.delete(0, tk.END)
        pressure_significant_entry.insert(0, str(pchange)) 

        cycle_distance_min_entry.delete(0, tk.END)
        cycle_distance_max_entry.delete(0, tk.END)
        cycle_distance_min_entry.insert(0, str(dmin))
        cycle_distance_max_entry.insert(0, str(dmax))
        cycle_distance_significant_entry.delete(0, tk.END)
        cycle_distance_significant_entry.insert(0, str(dchange))   



    @staticmethod
    def show_range_input_frame(master, range_frame_elements_tuple, visualizer=None, canvas=None, showing_cycle_var=None, showing_app_id_var=None, 
                               pressure_checkbox=None, current_checkbox=None, distance_checkbox=None):
        """
        Creates and displays a tkinter frame with elements allowing the user to input their 
        own ranges and changes values. 

        Args: 
            master (tkinter window): the window the frame will be displayed in 
            range_frame_elements_tuple (tuple of tkinter entry fields, 9 elements): the tuple of the tkinter ranges and changes input entries 
            visualizer (BaseVisualizer): a realtime visualizer containing the data the inputs apply to 
            canvas (tkinter canvas): the canvas the new data will be shown to when new inputs are applied
            showing_cycle_var (tkinter stringVar): the string var informing the user the cycle currently being displayed in the UI 
            showing_app_id_var (tkinter stringVar): ^(above arg but for app id)
            pressure, current and distance_checkbox (tkinter checkbutton object): the checkboxes in the realtime window checkbox frame

        Returns: 
            elements_tuple (tuple of tkinter entries, 9 elements): the entries for the range inputs that were created in this function 
            for the range input frame 

        """

        #master - master to show input frame on 
        #entry tuple - tuple of entry objects (can all be None) that will be created here
        (
            current_min_entry,
            current_max_entry,
            current_significant_entry,
            pressure_min_entry,
            pressure_max_entry,
            pressure_significant_entry,
            cycle_distance_min_entry,
            cycle_distance_max_entry,
            cycle_distance_significant_entry,
            use_defaults_button,
            use_maximums_button,
            process_range_button
        ) = range_frame_elements_tuple

      
        def use_max_ranges_and_changes(elements_tuple):
            """
            Plugs in the BaseWindow maximum bounds constants to the 
            ranges and changes inputs 

            Args:
                elements_tuple (tuple of tkinter entries, 9 elements): the entries for the ranges and changes inputs

            """
            max_values_tuple = (
                    BaseWindow.LOWEST_CURRENT_MIN_A, 
                    BaseWindow.HIGHEST_CURRENT_MAX_A,
                    BaseWindow.LARGEST_CURRENT_SIGNIFICANT_CHANGE_A,
                    BaseWindow.LOWEST_PRESSURE_MIN_PSI,
                    BaseWindow.HIGHEST_PRESSURE_MAX_PSI,
                    BaseWindow.LARGEST_PRESSURE_SIGNIFICANT_CHANGE_PSI,
                    BaseWindow.LOWEST_DISTANCE_MIN_MM,
                    BaseWindow.HIGHEST_DISTANCE_MAX_MM,
                    BaseWindow.LARGEST_DISTANCE_SIGNIFICANT_CHANGE_MM
                )
            BaseWindow.fill_ranges_and_changes(elements_tuple, max_values_tuple)


        def use_default_ranges_and_changes(elements_tuple):
            """
            See use_max_rnages_and_changes(), plugs in the Basewindow 
            default bounds constants instaed
            """
            default_values_tuple  = (
                        BaseWindow.DEFAULT_CURRENT_MIN_A,
                        BaseWindow.DEFAULT_CURRENT_MAX_A,
                        BaseWindow.DEFAULT_CURRENT_SIGNIFICANT_CHANGE_A,
                        BaseWindow.DEFAULT_PRESSURE_MIN_PSI,
                        BaseWindow.DEFAULT_PRESSURE_MAX_PSI,
                        BaseWindow.DEFAULT_PRESSURE_SIGNIFICANT_CHANGE_PSI,
                        BaseWindow.DEFAULT_DISTANCE_MIN_MM,
                        BaseWindow.DEFAULT_DISTANCE_MAX_MM,
                        BaseWindow.DEFAULT_DISTANCE_SIGNIFICANT_CHANGE_MM
                    )
            BaseWindow.fill_ranges_and_changes(elements_tuple, default_values_tuple)

    
        def validate_range_number(value_if_allowed, variable, significant_change):
            """
            User input validation function: allow only floats between the BaseWindow's set
            maximum bounds values
            Args: 
                value_if_allowed (string): can be either an empty string (meaning the user clicked 
                on the entry and hasn't entered anything yet) OR an "-" for negative values,
                OR can be a numerical floating point string. If the numerical value 
                of the string is beyond the maximum bounds valuesS, it will not be allowed to be typed 

                variable (string): the variable in relatime data that the given value is being used for 

                significant_change (int): indicates whether the value_if_allowed and value are for a 
                range bound entry (0) or a significant change entry(1)

            Returns: boolean: True if the value allowed is acceptable within the rules of the vcmd, 
            False if not 
            """

            if value_if_allowed == '' or value_if_allowed == '-':
                return True  # allow empty or negative for editing
            try:
                #if other variables are used, then the defaults would be the one below
                val = float(value_if_allowed)
                max_val = 1000.0
                min_val = -1000.0

                if variable == "Current (A)":
                    min_val = 0 if significant_change else BaseWindow.LOWEST_CURRENT_MIN_A 
                    max_val = BaseWindow.LARGEST_CURRENT_SIGNIFICANT_CHANGE_A if significant_change else BaseWindow.HIGHEST_CURRENT_MAX_A

                elif variable == "Pressure (PSI)":
                    min_val = 0 if significant_change else BaseWindow.LOWEST_PRESSURE_MIN_PSI
                    max_val = BaseWindow.LARGEST_PRESSURE_SIGNIFICANT_CHANGE_PSI if significant_change else BaseWindow.HIGHEST_PRESSURE_MAX_PSI
                    
                elif variable == "Cycle Distance (mm)":
                    min_val = 0 if significant_change else BaseWindow.LOWEST_DISTANCE_MIN_MM
                    max_val = BaseWindow.LARGEST_DISTANCE_SIGNIFICANT_CHANGE_MM if significant_change else BaseWindow.HIGHEST_DISTANCE_MAX_MM
            
                return min_val <= val <= max_val
            
            except ValueError:
                #Does not respond to blank input
                return False
                
        range_frame = tk.LabelFrame(master, text="Range Inputs")
        range_frame.pack(side='bottom', fill ='x', padx=10, pady=10, expand=True)  # <-- pack range_frame inside working_frame

        # --- Current Range and Change Section ---
        current_range_vcmd = (master.register(lambda value: validate_range_number(value, "Current (A)", False)), '%P')
        tk.Label(range_frame, text="Current Min (A):").grid(row=0, column=0, padx=5, pady=5, sticky='e')
        current_min_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=current_range_vcmd)
        current_min_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(range_frame, text="Max (A):").grid(row=0, column=2, padx=5, pady=5, sticky='e')
        current_max_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=current_range_vcmd)
        current_max_entry.grid(row=0, column=3, padx=5, pady=5)

        current_change_vcmd = (master.register(lambda value: validate_range_number(value, "Current (A)", True)), '%P')
        tk.Label(range_frame, text="Significant Change (A):").grid(row=0, column=4, padx=5, pady=5, sticky='e')
        current_significant_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=current_change_vcmd)
        current_significant_entry.grid(row=0, column=5, padx=5, pady=5)

        # --- Pressure Range Section ---
        pressure_range_vcmd = (master.register(lambda value: validate_range_number(value, "Pressure (PSI)", False)), '%P')
        tk.Label(range_frame, text="Pressure Min (PSI):").grid(row=1, column=0, padx=5, pady=5, sticky='e')
        pressure_min_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=pressure_range_vcmd)
        pressure_min_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(range_frame, text="Max (PSI):").grid(row=1, column=2, padx=5, pady=5, sticky='e')
        pressure_max_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=pressure_range_vcmd)
        pressure_max_entry.grid(row=1, column=3, padx=5, pady=5)

        pressure_change_vcmd = (master.register(lambda value: validate_range_number(value, "Pressure (PSI)", True)), '%P')
        tk.Label(range_frame, text="Significant Change (PSI):").grid(row=1, column=4, padx=5, pady=5, sticky='e')
        pressure_significant_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=pressure_change_vcmd)
        pressure_significant_entry.grid(row=1, column=5, padx=5, pady=5)

    
        # --- Cycle Distance Range Section (User enters in mm, internally stored as um) ---
        distance_range_vcmd = (master.register(lambda value: validate_range_number(value, "Cycle Distance (mm)", False)), '%P')
        tk.Label(range_frame, text="Cycle Distance Min (mm):").grid(row=2, column=0, padx=5, pady=5, sticky='e')
        cycle_distance_min_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=distance_range_vcmd)
        cycle_distance_min_entry.grid(row=2, column=1, padx=5, pady=5)

        tk.Label(range_frame, text=" Max (mm):").grid(row=2, column=2, padx=5, pady=5, sticky='e')
        cycle_distance_max_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=distance_range_vcmd)
        cycle_distance_max_entry.grid(row=2, column=3, padx=5, pady=5)

        distance_change_vcmd = (master.register(lambda value: validate_range_number(value, "Cycle Distance (mm)", True)), '%P')
        tk.Label(range_frame, text="Significant Change (mm):").grid(row=2, column=4, padx=5, pady=5, sticky='e')
        cycle_distance_significant_entry = tk.Entry(range_frame, width=7, validate='key', validatecommand=distance_change_vcmd)
        cycle_distance_significant_entry.grid(row=2, column=5, padx=5, pady=5)

        entries_tuple = (
            current_min_entry,
            current_max_entry,
            current_significant_entry,
            pressure_min_entry,
            pressure_max_entry,
            pressure_significant_entry,
            cycle_distance_min_entry,
            cycle_distance_max_entry,
            cycle_distance_significant_entry,
        )

        process_range_button = None

        use_maximums_button = tk.Button(
            range_frame, text="Use Maximums", command=lambda: use_max_ranges_and_changes(entries_tuple)
        )
        use_maximums_button.grid(row=1, column=6, padx=10, pady=5)

        use_defaults_button = tk.Button(
            range_frame, text="Use Defaults", command=lambda: use_default_ranges_and_changes(entries_tuple)
        )
        use_defaults_button.grid(row=0, column=6, padx=10, pady=5)

        if isinstance(master, (tk.Frame, tk.LabelFrame)):
            
            #define button for new submission
            process_range_button = tk.Button(
            range_frame,
            text="Set Ranges and Changes",
            bg='green',
            fg='white',
            activebackground='green',
            activeforeground='white',
            disabledforeground='gray'
            )
            process_range_button.grid(row=3, column=6, padx=5, pady=5)

        #warning label
        info_label = tk.Label(range_frame, text="Note: Tight range bounds and small significant change values will increase processing time", font=("Arial", 10))
        info_label.grid(
        row=3, column=0, columnspan=6,  # Span across all columns (adjust span if needed)
        sticky='w',                     # Left-align within the grid cell
        padx=5, pady=(20, 5))

        elements_tuple = (
            current_min_entry,
            current_max_entry,
            current_significant_entry,
            pressure_min_entry,
            pressure_max_entry,
            pressure_significant_entry,
            cycle_distance_min_entry,
            cycle_distance_max_entry,
            cycle_distance_significant_entry,
            use_defaults_button,
            use_maximums_button,
            process_range_button
        )

        if process_range_button is not None:
            process_range_button.config(command=lambda: BaseWindow.try_ranges_and_changes(elements_tuple, visualizer, canvas, showing_cycle_var, showing_app_id_var,
                                                                                          pressure_checkbox, current_checkbox, distance_checkbox))
        return elements_tuple



       
    @staticmethod
    def handle_variable_range_submit(entry_widget_min, entry_widget_max, variable_name="Value"):
        """
        Gets the string values in the given entry_widget_min and max entry fields, checks them, 
        and returns a float representation of these numbers. Displays window to user if the value was 
        not entered 

        Args: 
            entry_widget_min and entry_widget_max (tkinter entry field): the entry field that contains a numerical
            string representation of the significant change the user wants to see 
            (validated by a vcmd above)

            variable_name: the name of the significant change variable the entries correspond to

        Returns: 
            min, max (float tuple): tuple of float values of the min and max values 

        """
        min = entry_widget_min.get().strip()
        max = entry_widget_max.get().strip()

        if min == '' or max == '':
            messagebox.showwarning("Missing Input", f"Please enter a value for {variable_name}.")
            return None, None
        
        num_min = float(min)
        num_max = float(max)

        if num_max < num_min:
                messagebox.showwarning("Incorrect Range", f"{variable_name} Min must be <= {variable_name} Max.")
                return None, None

        return num_min, num_max
    
    @staticmethod
    def handle_variable_change_submit(entry_widget_change, variable_name="Value"):
        """
        Gets the string value in the given entry_widget_change field, checks it, and returns 
        a float representation of this number. Displays window to user if the value was 
        not entered 

        Args: 
            entry_widget_change (tkinter entry field): the entry field that contains a numerical
            string representation of the significant change the user wants to see 
            (validated by a vcmd above)

            variable_name: the name of the significant change variable the entry corresponds to

        Returns:
            significant change (float): float representation of the significant change value
        """

        change = entry_widget_change.get().strip()

        #vcmd will handle negative numbers and maxes
        if change == '':
            messagebox.showwarning("Missing Input", f"Please enter a value for {variable_name}.")
            return None
        
        return float(change)






        
        
        














class SequentialWindow(BaseWindow):
    """
    CHILD CLASS OF BaseWindow
    The realtime window contains everything the basewindow does 
    and in addition contains: 

    A variable selector for every haeder variable in the sequential file 
    that will display the datapoints of that header for the 
    selected range in the checkbutton frame (instead of checkbuttons) 
    """

    def __init__(self, master, sequential_visualizer):
        """
        Initializes the BaseWindow this window will be created from, as well as 
        creates the button that allows users to select what type of data they want to see 
        in the trend graph. 

        Sets it's visualizers cycle number to one and sets the UI to reflect this
        showing cycle one when first displayed 

        Args: 
            master (tkinter window/root): The tkinter window or root that this window was generated from 

            sequential_visualizer (Sequential Visualizer object): the visualizer this window will 
            user to display it's sequential data 
        """

        super().__init__(master, "Sequential Window", sequential_visualizer)
   
        excluded_from_dropdown_cols = [sequential_visualizer.grade_column_title, sequential_visualizer.cycle_end_column_title, sequential_visualizer.stop_column_title, 'ApplicationId'] 

        columns_for_dropdown = [col for col in sequential_visualizer.dataframe.columns if col not in excluded_from_dropdown_cols]

        self.selected_trend = tk.StringVar(value=sequential_visualizer.dataframe.columns[0])  # Default value

        trend_dropdown = tk.OptionMenu(
            self.checkbox_frame,
            self.selected_trend,
            *columns_for_dropdown,   # dropdown options
        )
        trend_dropdown.config(font=("Arial", 12, "bold"))
        trend_dropdown.pack(side=tk.LEFT, padx=5)

        self.visualizer.set_cycle_num(1)
        self.visualizer.show_current_cycle_num(self.selected_trend.get())
        self.canvas.draw()




  



        


class RealtimeWindow(BaseWindow):
    """
    CHILD CLASS OF BaseWindow
    The realtime window contains everything the basewindow does 
    and in addition contains: 

    Three checkboxes in the checkbox frame used for the three 
    most common variables in the realtime data 
    (current, pressure, and distance)

    It's own ranges and changes input frame with full functionality 
    as well as an option to process and display new ranges and changes inputs 
    against the same file and visualizer that belongs to the window 
    """

    def __init__(self, master, realtime_visualizer):
        """
        Initializes the BaseWindow this window will be created from, as well as 
        creates the three checkbuttons allowing the user to pick which variables are displayed
        and creates a new range input frame for the user to interact with

        Sets it's visualizers cycle number to one and sets the UI to reflect this
        showing cycle one when first displayed 

        Args: 
            master (tkinter window/root): The tkinter window or root that this window was generated from 

            realtime_visualizer (Sequential Visualizer object): the visualizer this window will 
            user to display it's realtime data 
        """

        super().__init__(master, "Realtime Window", realtime_visualizer)
        

        self.show_pressure_var = tk.IntVar(value=1)
        self.show_current_var = tk.IntVar(value=1)
        self.show_distance_var = tk.IntVar(value=1)

        tk.Checkbutton(self.checkbox_frame, text="Pressure (PSI)", variable=self.show_pressure_var,  font=("Arial", 12, "bold"), 
                                                            command=self.update_plot_visibility).pack(side=tk.LEFT, padx=5)
        tk.Checkbutton(self.checkbox_frame, text="Standard Current (A)", variable=self.show_current_var,  font=("Arial", 12, "bold"), 
                                                            command=self.update_plot_visibility).pack(side=tk.LEFT, padx=5)
        tk.Checkbutton(self.checkbox_frame, text="Cycle Distance (mm)", variable=self.show_distance_var,  font=("Arial", 12, "bold"), 
                                                            command=self.update_plot_visibility).pack(side=tk.LEFT, padx=5)
        
        self.report_all_button = tk.Button(
            self.cycle_tab_cycle, text="CSV Report of Data For Set Ranges, All Variables, All Cycles", command=self.handle_report_button_all,
        )
        self.report_all_button.grid(row=2, column=8, padx=10, pady=5, sticky='e')

        self.report_all_button = tk.Button(
            self.cycle_tab_app_id, text="CSV Report of Data For Set Ranges, All Variables, All Cycles", command=self.handle_report_button_all,
        )
        self.report_all_button.grid(row=2, column=8, padx=10, pady=5, sticky='e')


        self.current_min_entry = None
        self.current_max_entry = None
        self.current_significant = None
        self.pressure_min_entry = None
        self.pressure_max_entry = None
        self.pressure_significant_entry = None
        self.cycle_distance_min_entry = None
        self.cycle_distance_max_entry = None
        self.cycle_distance_significant_entry = None
        self.use_defaults_button = None
        self.use_maximums_button = None
        self.process_range_button = None

        range_frame_elements_tuple = (
            self.current_min_entry,
            self.current_max_entry,
            self.current_significant,
            self.pressure_min_entry,
            self.pressure_max_entry,
            self.pressure_significant_entry,
            self.cycle_distance_min_entry,
            self.cycle_distance_max_entry,
            self.cycle_distance_significant_entry,
            self.use_defaults_button,
            self.use_maximums_button,
            self.process_range_button
        )

     
        good_elements_tuple = BaseWindow.show_range_input_frame(self.controls_frame, range_frame_elements_tuple, realtime_visualizer, 
                                                                self.canvas, self.cycle_range_var, self.app_id_range_var, 
                                                                self.show_pressure_var, self.show_current_var, self.show_distance_var)
        entries_tuple  = good_elements_tuple[:9]

        BaseWindow.fill_ranges_and_changes(entries_tuple, realtime_visualizer.ranges_and_changes_tuple)

        self.visualizer.set_cycle_num(1)
        self.visualizer.show_current_cycle_num(self.visualizer.current_label, self.visualizer.pressure_label, self.visualizer.distance_label)
        self.canvas.draw()

""" UI CLASSES END"""  
    
   


        





    
        

    


       




























""" UI FUNCTIONS BELOW TO START PROGRAM """

def select_csv_file(file_frame, update_callback):

    """
    Allows the user to select only CSV files by opening their file explorer, and adds them 
    to the selected files shown in the UI. The full file path will be displayed 

    Args: 
        file_frame (tkinter frame object) the frame where the file path will be displayed
        
        update_callback (function ref.): the callback to where program flow will return to 
    """

    file_paths = filedialog.askopenfilenames(
        title="Select a CSV file",
        filetypes=[("CSV files", "*.csv")]
    )

    if not file_paths:
        
        return
    
    currently_selected_files.extend(file_paths)
    update_callback(file_frame)


def remove_file(index, file_frame, update_callback):

    """
    Removes the file path from the users selected file list as well as from the UI

    Args: 
        file_frame (tkitner frame object): the frame where the file path is diplayed 
        
        update_callback (function ref.): the callback where program flow will return to 
    """

    if 0 <= index < len(currently_selected_files):
        del currently_selected_files[index]
        update_callback(file_frame)


def update_file_labels(file_frame):

    """
    Responsible for updating the UI with the files the user has selected or removed 

    Args: 
        file_frame (tkinter frame object): the frame the file paths will be displayed in
    """
    for widget in file_frame.winfo_children():
        widget.destroy()

    for idx, file_path in enumerate(currently_selected_files):
        row = tk.Frame(file_frame)
        row.pack(fill="x", padx=10, pady=2)

        label = tk.Label(row, text=f"File {idx + 1}: {file_path}", anchor="w")
        label.pack(side="left", fill="x", expand=True)

        remove_btn = tk.Button(row, text="Remove", fg="white", bg="red", command=lambda i=idx,: remove_file(i, file_frame, update_file_labels))
        remove_btn.pack(side="right")


def on_process(root, range_frame_elements_tuple, button):

    """
    This function defines what happens when the user clicks the green 'process' button 

    The function checks if there is at least 1 selected file, disables the process button 
    from being pushed, then creates a data_processor object to validate all the CSV file types and contents.
    It determines which files have the right information to be loaded, and then process the data in those files
    Finally, it creates a unique visualizer object for each file and displays either a sequential or realtime 
    window using the unique visualizers.

    If any file given does not have proper formatting or does not have the the right  information 
    (see data_loader.py check files() functions), or If a file has the right information but within 
    the file any data cannot be parsed, a window will present itself, informing the user which files are invalid, 
    which cannot be parsed, and if they would like to continue with any valid files or if they would like to go
    back 

    Args: 
        root (tkinter window/root): The tkinter root this window will branch off of 

        range_frame_elements_tuple (tkinter entries tuple of 9 elements): the tkinter entries 
            carrying the numerical string data the user input in the range inputs frame 

        button (tkinter button object): the button pushed that called this handler function
    """


    global currently_selected_files
    global previously_processed_files

    # No go if no files are selected 
    if not currently_selected_files:
        messagebox.showwarning("No Files", "Please select at least one CSV file.")
        return

    # Disable the button after click 
    button.config(state="disabled")

    (
     current_min, 
     current_max, 
     current_change, 
     pressure_min, 
     pressure_max,
     pressure_change,  
     cycle_distance_min, 
     cycle_distance_max, 
     distance_change_in_mm) = BaseWindow.get_ranges_and_changes(range_frame_elements_tuple)

    if any(input is None for input in [current_min, 
                                       current_max, 
                                       current_change, 
                                       pressure_min, 
                                       pressure_max,
                                       pressure_change,  
                                       cycle_distance_min, 
                                       cycle_distance_max, 
                                       distance_change_in_mm]):
        #warning already shown at this point
        return
    
  
    
    
    #Create a new processor
    processor = DataProcessor()
 
    #check all the files user selected, returns only the ones that are good to process
    valid_file_info, invalid_files= processor.check_files(currently_selected_files)

 
    invalid_file_string = ""
    if len(invalid_files) > 0: 
        invalid_file_string = '\n'.join(invalid_files)
        proceed = messagebox.askyesno("Continue?", "The following files are invalid and will not be processed. Would you like to continue with any remaining valid files?\n"
                                      f"{invalid_file_string}")
        
        #return to menu if user chooses not to proceed or no valid files
        if (not proceed) or (not valid_file_info): 
            #re enable process button
            BaseWindow.reactivate_button(button)
            return
            
    #attempt to read all data from valid files. Exception likely thrown if data is corrupted/unreadable
    valid_file_data = [] 
                                                                               
    try: 
        valid_file_data, unparsable_files = processor.process_files(valid_file_info,
                                                                    current_min, 
                                                                    current_max,
                                                                    current_change,  
                                                                    pressure_min, 
                                                                    pressure_max, 
                                                                    pressure_change, 
                                                                    cycle_distance_min, 
                                                                    cycle_distance_max, 
                                                                    distance_change_in_mm)
    except FileNotFoundError as e:
        messagebox.showerror("Ensure you have a copy of the 'Next Gen Data Logging.xlsx', " \
        "'MDL_params_mapping.xlsx', and 'ADL Variable Enums.xlsx' in the 'refs' folder.")
    
    unparsable_file_string = ""
    for file in unparsable_files:
        unparsable_file_string += (file + "\n")
    
    if unparsable_files:
        proceed = messagebox.askyesno("Continue?", "The following files cannot be parsed. "\
                                      "Would you like to continue with any remaining valid files?\n"
                                      f"{unparsable_file_string}")
        
        if (not proceed) or (not valid_file_info): 
            #re enable process button
            BaseWindow.reactivate_button(button)
            return   
            
    # re enable process button after the processing is done
    button.config(state="active")
    button.config(bg='green', activebackground='green')

    for i in range (0, len(valid_file_data), 4):
        
        filetype = valid_file_data[i]
        filepath = valid_file_data[i+1]
        dataframe = valid_file_data[i+2]   
        metadata = valid_file_data[i+3]

        if valid_file_data[i] == 's':
            
            visualizer = SequentialVisualizer(filepath, dataframe, metadata, BaseWindow.get_ranges_and_changes(range_frame_elements_tuple))
            window = SequentialWindow(root, visualizer)

        elif filetype == 'r':
            visualizer = RealtimeVisualizer(filepath, dataframe, metadata, BaseWindow.get_ranges_and_changes(range_frame_elements_tuple))
            window = RealtimeWindow(root, visualizer)
        
        

def launch_ui():

    """
    This function launches the tkinter UI and establishes it as the main loop 
    in the program. The program will be driven by button presses and user interactions
    after this function runs. Called from main.py

    Creates the home window where users can upload and remove CSV files, 
    input ranges and changes values, and create new data viewing windows via 
    the process button
    
    """


    root = tk.Tk()
    root.title("Force Logic MDL Engineering Dashboard")
    root.geometry("800x400")
    
   #Frame to group button and label horizontally
    upload_frame = tk.Frame(root)
    upload_frame.pack(pady=20)

    upload_btn = tk.Button(upload_frame, text="Upload CSV Files", font=("Arial", 14),
                           command=lambda: select_csv_file(file_frame, update_file_labels))
    upload_btn.pack(side="left", padx=10)

    

    global file_frame
    file_frame = tk.Frame(root)
    file_frame.pack(fill="x", expand=False, pady=(10,0))

    
    initial_current_min_entry = None
    initial_current_max_entry = None
    initial_current_significant = None
    initial_pressure_min_entry = None
    initial_pressure_max_entry = None
    initial_pressure_significant_entry = None
    initial_cycle_distance_min_entry = None
    initial_cycle_distance_max_entry = None
    initial_cycle_distance_significant_entry = None
    initial_use_defaults_button = None
    initial_use_maximums_button = None
    initial_process_range_button = None

    initial_range_frame_elements_tuple = (
        initial_current_min_entry,
        initial_current_max_entry,
        initial_current_significant,
        initial_pressure_min_entry,
        initial_pressure_max_entry,
        initial_pressure_significant_entry,
        initial_cycle_distance_min_entry,
        initial_cycle_distance_max_entry,
        initial_cycle_distance_significant_entry,
        initial_use_defaults_button,
        initial_use_maximums_button,
        initial_process_range_button
    )


    #process button
    process_btn = tk.Button(root, text = "Process", font=("Arial", 14), bg="green", fg="white", disabledforeground='gray')
    process_btn.pack(side='bottom', pady=(10,10))

    global currently_selected_files

    initial_range_frame_elements_tuple = BaseWindow.show_range_input_frame(root, initial_range_frame_elements_tuple)

    process_btn.config(command=lambda b=process_btn: on_process(root, initial_range_frame_elements_tuple, b))
    
    root.mainloop()
    
