"""
Author: Derek Achen - derek.achen@milwaukeetool.com
Date: 06/04/2025
Dept: P&E NPD, Hydraulics Team

This project is meant to help summarize and visualize both sequential and realtime 
data collected by tool firmware and defined in the Next Gen Data Logging excel workbook on the New LUT Definition and 
New RT Definition sheets. This project provides a comprehensive UI where users upload 
CSV files (realtime or sequential) acquired from MT's Quick Link MDL containing 
data from The Hydraulic Tools life cycle tests, and then are presented with visual summaries of 
the life test data, separated into a sequential window and realtime window.
 Users can customize which portions of the data they see, specifically by 
a range of cycles from the data logs, as well as custom graphs of different variables available 
to them. Additionally, users can compare the data to range values they set and analyze the 
data against those bounds.
"""
import ui

if __name__ == "__main__":
    ui.launch_ui()
    
    