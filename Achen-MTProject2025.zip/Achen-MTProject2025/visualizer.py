import matplotlib as plt
import numpy as np
from matplotlib.figure import Figure
import time as tm
import csv
import re
import os 


"""
The following visualizer classes are tailor made for the ForceLogic GenI 
tools and the specific sequential and realtime parameters they pull from the 
tool. Some of the implementation may work with other parameters, especially 
entierly numerical ones, but is only guranteed to work with the 
GenI Force Logic P&E tools.
"""



class BaseVisualizer:
    """
    PARENT CALSS FOR SEQUENTIAL + REALTIME VISUALIZERS

    The BaseVisualizer class defines functionality that both the 
    sequential and realtime visualizers use. Both visualizers show 
    the data by the cycle that the tool has run, and keeps track of the 
    current cycle range or cycle number it is showing on the graph. 
    The sequential and realtime visualizers present different data in different ways
    """

    

    def __init__(self, filepath, data, metadata, ranges_and_changes_tuple):
        """
        Constructs a Basevisulizer object and instantiates appropriate variables. 
        Finds min and max app id in the cycle, as well as missing app id's as well 

        Args: 
            filepath (string): filepath of the sequential or realtime data CSV file the visualizer is using
            data (pandas dataframe): the pandas dataframe representation of the data in the given CSV file
            metadata (list): the generated metadata from the data_loader after the file was processed
            ranges_and_chanes_tuple (tuple of floats, 9 elements): float values of the ranges and changes in the ranges input frame 
        """

        self.filepath = filepath

        self.filename = os.path.basename(self.filepath)
        
        #reges requires 10 alphanumeric chars, at least 1 of each
        match = re.search(r'(?=.*[A-Za-z])(?=.*\d)[A-Za-z0-9]{10}', self.filename)

        self.mpbid = ""
                          
        if match:
            self.mpbid = match.group(0)

        #this is a dataframe 
        self.dataframe = data
        self.metadata = metadata

        #index of the data in the each tuple that is the metadata element at any index
        self.MTDATA_CYCLE_START_IDX = 0
        self.MTDATA_STATS_IDX = 1
        self.MTDATA_CORRECTED_DATA_IDX = 2
        self.MTDATA_SIGNIFICANT_CHANGES_IDX = 3
        self.MTDATA_OUT_OF_BOUNDS_IDX = 4

        #if a cycle range is being shown, this 
        #will be the same value as current_cycle_range_min
        self.current_cycle = 1
        self.current_cycle_range_min = 1
        self.current_cycle_range_max = 1

        self.ranges_and_changes_tuple = ranges_and_changes_tuple

        self.min_app_id, self.max_app_id = self.get_min_and_max_app_id()
        self.present_ids, self.missing_ids = self.generate_present_and_missing_app_id_lists_in_range(self.min_app_id, self.max_app_id + 1)
        
        self.figure = None

        self.current_label = 'Standard Current (A)'
        self.pressure_label = 'Pressure (PSI)'
        self.distance_label = 'Cycle Distance (mm)'
        self.corrected_point_label = 'Corrected datapoint'
        self.current_and_distance_label = f"{self.current_label} and {self.distance_label}"

    
    def get_figure(self):
        """
        Returns the visualizers figure for it's plot(s)
        """
        return self.figure
    
    def set_cycle_range(self, min, max):
        """
        Sets the visualizers current range min and max, 
        and sets the current cycle value to the min 

        Args: 
            min (int): cycle range min value 
            max (int): cycle range max value
        """

        #args are safe from ui handling 
        self.current_cycle_range_min = min
        self.current_cycle_range_max = max
        self.current_cycle = self.current_cycle_range_min

    def set_cycle_num(self, cycle_num):
        """
        Sets the visualizers current cycle number

        Args: 
            cycle_num (int): the cycle number
        """
        self.current_cycle = cycle_num
        self.set_cycle_range(cycle_num, cycle_num)

    

    





"""CHILD CLASSES"""


class SequentialVisualizer(BaseVisualizer):
    """
    This class provides data analysis and plotting for sequential CSV file data 
    It provides a mapping of enums in the ADL Variable Enums Excel sheet to colors 
    that make sense and can be changed, as well as a bar chart for the three 
    Enumerated types that appear in a sequential file (crimp grade, cycle end reason, and
    tool stop reason). Additionally, a 4th scatter plot is shown and any variable not on a bar chart
    can be viewed per cycle or per cycle range in that plot
    """

    #Matplotlib is capable of using all the CSS4 colors. Find the list here: 
    #https://matplotlib.org/stable/gallery/color/named_colors.html - CSS Colors tab
    
    STATUS_COLOR_MAP = {
    #Crimp Grade Enums
    "fault": "red",
    "fail": "darkred",
    "pass": "green",
    "unknown": "gray",
    "withdrawn": "lightgray",
    "fullpressure": "blue",
    "cutcomplete": "cyan",
    "manualrelief": "orange",

    # CycleEndReasonEnum (dump reason)
    "cycleunknown": "gray",
    "cyclefullpressure": "blue",
    "cyclefullextension": "deepskyblue",
    "cycleelectronicrelease": "dodgerblue",
    "cyclemanualrelief": "orange",
    "cyclemred": "purple",
    "cycletoolerror": "red",
    "cycletoolsleep": "teal",
    "cyclepackremoved": "brown",
    "cyclefault": "red",

    # DoubleTapTriggerStatusEnum
    "doubletapnodoubletap": "gray",
    "doubletapimmediatereset": "orange",
    "doubletaptimedreset": "gold",
    "doubletapcyclereset": "deepskyblue",
    "doubletaptimedcyclereset": "dodgerblue",
    "doubletapmaxval": "purple",
    "doubletapfault": "red",

    # ToolStopReasonEnum
    "toolstopunknown": "gray",
    "toolstopfullpressure": "blue",
    "toolstopfullextension": "deepskyblue",
    "toolstopelectronicrelease": "dodgerblue",
    "toolstopmred": "purple",
    "toolstoptriggerrelease": "orange",
    "toolstoptimeout": "gold",
    "toolstophallerror": "red",
    "toolstoplastapp": "teal",
    "toolstopbatteryhandshake": "limegreen",
    "toolstoppressureerror": "red",
    "toolstopmcuthermal": "orangered",
    "toolstopfetthermal": "darkorange",
    "toolstopcurrentfault": "red",
    "toolstopshortfet": "red",
    "toolstopmotorfault": "red",
    "toolstopstall": "darkred",
    "toolstopbatterytemp": "orangered",
    "toolstopgatedriveerror": "red",
    "toolstopmotorthermalmodel": "orangered",
    "toolstopcapacitorthermalmodel": "orangered",
    "toolstopappalignmentfault": "red",
    "toolstopdataloggerfull": "goldenrod",
    "toolstoppressureguardrailfault": "red",
    "toolstopremoteerror": "red",
    "toolstopservicecyclecount": "blue",
    "toolstopdataloggerflasherror": "red",
    "toolstopmvstrike": "red",
    "toolstopesdstrike": "red",
    "toolstopclevispinfault": "red",
    "toolstopcrimpingdiefault": "red",
    "toolstopfuseopen": "red",
    "toolstopfuseaccumulator": "red",
    "toolstopregulatoroutofbounds": "red",
    "toolstopcutdetection": "cyan",
    "toolstopmanualrelief": "orange",
    "toolstopdistancesensorerror": "red",
    "toolstoptransportlockout": "gray",
    "toolstopfault": "red",
}

    GRADE_DICT_POS = 0
    END_DICT_POS = 1
    STOP_DICT_POS = 2

    def __init__(self, filepath, sequential_data, sequential_metadata, ranges_and_changes_tuple):
        """
        Constructs a SequentialVisualizer object 
        Passes args to parent BaseVisualizer to be created, as well as 
        instantiates necessary variables and edits the metadata to contain color data for each cycle
        Creates axes for the variables that are available in the file 

        Args:
            See BaseVisualizer's args list

        """

        super().__init__(filepath, sequential_data, sequential_metadata, ranges_and_changes_tuple)

        self.total_cycles = len(sequential_data)

        map_accessible_by_metadata_dict_statuses = self.clean_status_color_map(SequentialVisualizer.STATUS_COLOR_MAP, prefixes_to_strip=["cycle", "toolstop", "doubletap"])

        new_metadata = [{} for _ in range(len(sequential_metadata))]

        for i in range(len(sequential_metadata)):
            working_dict = new_metadata[i]
            
            for enum_value, status in sequential_metadata[i].items():
                color = map_accessible_by_metadata_dict_statuses.get(status, 'gray') #default to gray
                working_dict[enum_value] = (status, color)

        self.metadata = new_metadata

        self.figure = Figure()
        self.figure.set_size_inches(5,4, forward=True)
        
        self.grade_title = "Grade"
        self.end_title = "Cycle End Reason"
        self.stop_title = "Tool Stop Reason"

        self.grade_column_title = "Grade (Unitless)"
        self.cycle_end_column_title = "Dump Reason (Unitless)"
        self.stop_column_title = "Tool Stop Reason (Unitless)"

        self.grade_ax = None
        self.cycle_end_reason_ax = None
        self.tool_stop_reason_ax = None
        self.trend_ax = None
        
        if self.grade_column_title in self.dataframe.columns:
            
            self.grade_ax = self.figure.add_subplot(2, 2, 1)

        if self.cycle_end_column_title in self.dataframe.columns:

            self.cycle_end_reason_ax = self.figure.add_subplot(2, 2, 2)

        if self.stop_column_title in self.dataframe.columns:
            
            self.tool_stop_reason_ax = self.figure.add_subplot(2, 2, 3)

        self.trend_ax = self.figure.add_subplot(2, 2, 4)

        self.figure_title = f"Sequential Data in {self.filename}\nMPBID: {self.mpbid}"
        self.figure.suptitle(self.figure_title)



    def clean_status_color_map(self, original_map, prefixes_to_strip):
        """
        Strips the original map of the prefixes that are already shown on the 
        graph title, when this map is clean you just see the reason 
        and not "toolstopfullpressure" you just see "fullpressure"
        makes graph less cluttery when plotting 

        Args: 
            original_map (enum list string: string): a mapping of string enums to matplotlib colors 
            prefixes_to_strip (list): list of strings to strip from the string enums in the original map

        Returns:    
            temp_map (enum list string: string): a mapping of clean string : color mapping enums
        """
        temp_map = {}
        seen = set()

        for full_key, color in original_map.items():
            #remove known prefixes
            base_key = full_key
            for prefix in prefixes_to_strip:
                if base_key.startswith(prefix):
                    base_key = base_key[len(prefix):]
                    break  #only strip one prefix

            #only keep the first instance of each base_key
            if base_key not in seen:
                temp_map[base_key] = color
                seen.add(base_key)

        return temp_map


    def show_current_cycle_num(self, trend_var=None):
        """
        Shows the data of the visualizer's current set cycle num to the graph(s)
        in the canvas. Lists string representation of enum value for the 
        crimp grade, cycle end reason, and tool stop reason columns (each has their own bar chart
        if it was found in the data)
        as well as plots the trend_var if chosen in a fourth scatter plot 

        Args: 
            trend_var (string): the column label in the sequential data file that 
                the user wants to see
        """

        single_hist_value = 1

        if self.grade_ax is not None:

            self.grade_ax.cla()

            grade_enum = self.dataframe.loc[self.current_cycle - 1, self.grade_column_title]

            label, color = self.metadata[SequentialVisualizer.GRADE_DICT_POS][grade_enum]

            self.grade_ax.hist([single_hist_value], color=color)
            self.grade_ax.set_title(self.grade_title)
            self.grade_ax.set_xlabel(label) 
            
        if self.cycle_end_reason_ax is not None:

            self.cycle_end_reason_ax.cla()

            end_enum = self.dataframe.loc[self.current_cycle - 1, self.cycle_end_column_title]
            label, color = self.metadata[SequentialVisualizer.END_DICT_POS][end_enum]
           
            self.cycle_end_reason_ax.hist([single_hist_value], color=color)
            self.cycle_end_reason_ax.set_title(self.end_title)
            self.cycle_end_reason_ax.set_xlabel(label)


        if self.tool_stop_reason_ax is not None:

            self.tool_stop_reason_ax.cla()

            stop_enum = self.dataframe.loc[self.current_cycle - 1, self.stop_column_title]
            label, color = self.metadata[SequentialVisualizer.STOP_DICT_POS][stop_enum]

            self.tool_stop_reason_ax.hist([single_hist_value], color=color)
            self.tool_stop_reason_ax.set_title(self.stop_title)
            self.tool_stop_reason_ax.set_xlabel(label)

        #plot trend of current variable selected for cycle
        if trend_var is not None:
            
            self.trend_ax.cla()

            y_val = self.dataframe.loc[self.current_cycle - 1][trend_var]
            self.trend_ax.scatter(self.current_cycle, y_val, color='black')
            self.trend_ax.set_title(f"{trend_var} for Cycle: {self.current_cycle}")
            self.trend_ax.set_xlabel(f"{self.current_cycle}")
            self.trend_ax.set_xticks([])
            self.trend_ax.set_ylabel(f"{trend_var}")

        self.figure.tight_layout()
    
        
    def show_curent_cycle_range(self, trend_var=None):
        """
        Shows the data of the visualizer's current set cycle range to the graph(s)
        in the canvas. Lists string representations of enum values for the 
        crimp grade, cycle end reason, and tool stop reason columns (each has their own bar chart
        if it was found in the data)
        as well as plots the trend_var if chosen in a fourth scatter plot 

        Args: 
            trend_var (string): the column label in the sequential data file that 
                the user wants to see
        """



        #want them all to be scaled to the total cycle nums in the range
        y_limit = (self.current_cycle_range_max - self.current_cycle_range_min) + 1

        if self.grade_ax is not None:

            self.grade_ax.cla() 

            counts, labels, bar_colors  = self.get_bar_data_for_range(self.grade_column_title)
            x = list(range(len(labels)))

            self.grade_ax.bar(x, counts, color=bar_colors, width=0.4)
            self.grade_ax.set_title(self.grade_title)

            self.grade_ax.set_xticks(x)
            self.grade_ax.set_xticklabels(labels, rotation=45, ha='right')

            self.grade_ax.set_ylim(0, y_limit)

            if len(x) == 1:
                self.grade_ax.set_xlim(-0.5, 0.5)
            else:
                self.grade_ax.set_xlim(-0.5, len(x) - 0.5)

        if self.cycle_end_reason_ax is not None: 

            self.cycle_end_reason_ax.cla()

            counts, labels, bar_colors = self.get_bar_data_for_range(self.cycle_end_column_title)
            x = list(range(len(labels)))

            self.cycle_end_reason_ax.bar(x, counts, color=bar_colors, width=0.4)
            self.cycle_end_reason_ax.set_title(self.end_title)

            self.cycle_end_reason_ax.set_xticks(x)
            self.cycle_end_reason_ax.set_xticklabels(labels, rotation=45, ha='right')

            self.cycle_end_reason_ax.set_ylim(0, y_limit)

            if len(x) == 1:
                self.cycle_end_reason_ax.set_xlim(-0.5, 0.5)
            else:
                self.cycle_end_reason_ax.set_xlim(-0.5, len(x) - 0.5)

        
        if self.tool_stop_reason_ax is not None: 

            self.tool_stop_reason_ax.cla()

            counts, labels, bar_colors = self.get_bar_data_for_range(self.stop_column_title)
            x = list(range(len(labels)))



            self.tool_stop_reason_ax.bar(x, counts, color=bar_colors, width=0.4)
            self.tool_stop_reason_ax.set_title(self.stop_title)

            self.tool_stop_reason_ax.set_xticks(x)
            self.tool_stop_reason_ax.set_xticklabels(labels, rotation=45, ha='right')

            self.tool_stop_reason_ax.set_ylim(0, y_limit)

            if len(x) == 1:
                self.tool_stop_reason_ax.set_xlim(-0.5, 0.5)
            else:
                self.tool_stop_reason_ax.set_xlim(-0.5, len(x) - 0.5)

        if trend_var is not None: 

            self.trend_ax.cla() 

            x_vals = list(range(self.current_cycle_range_min, self.current_cycle_range_max + 1))
            y_vals = self.dataframe.iloc[self.current_cycle_range_min - 1:self.current_cycle_range_max][trend_var]
            self.trend_ax.scatter(x_vals, y_vals, color='black')
            self.trend_ax.set_title(f"{trend_var} for Cycles: {self.current_cycle_range_min} to {self.current_cycle_range_max}")
            self.trend_ax.set_xlabel(f"Cycle {self.current_cycle_range_min} to {self.current_cycle_range_max}")
            self.trend_ax.set_xticks(list(range(self.current_cycle_range_min, self.current_cycle_range_max + 1)))
            self.trend_ax.set_ylabel(f"{trend_var}")
            self.trend_ax.grid(True)

        self.figure.tight_layout()

    
    def get_bar_data_for_range(self, column_title):
        """
        Gets the bar graph data for the currently set cycle range in the visualizer
        for the given title that uses a bar graph (grade, end reason, or tool stop reason)
        Bar data includes the labels of the graph, the colors for each bar, and the numerical 
        value of each bar. Assembles this data into a list and returns 

        Args: 
            column_title (string): the column that bar chart will represent for the range 
            (in this implementation, only the grade, cycle end reason and tool stop reason
            get a bar chart) 

        Returns: 
            tuple of 3 elements:
            labels (list): list of strings for each bar label in order of L to R on the bar graph
            bar_colors (list): list of color strings for each bar label in order of L to R on bar graph 
            counts (list): list of ints of the value/height of each bar in the graph from L to R 
        """
        
        sub_df = self.dataframe.loc[self.current_cycle_range_min - 1 : self.current_cycle_range_max - 1, column_title]

        enum_counts = sub_df.value_counts()
        total_rows = len(sub_df)

        enum_dict_pos = None
        if column_title == self.grade_column_title:
            enum_dict_pos = SequentialVisualizer.GRADE_DICT_POS
        elif column_title == self.cycle_end_column_title:
            enum_dict_pos = SequentialVisualizer.END_DICT_POS
        elif column_title == self.stop_column_title:
            enum_dict_pos = SequentialVisualizer.STOP_DICT_POS

        labels = []
        bar_colors = []
        counts = []

        for grade_enum, count in enum_counts.items():
            label, color = self.metadata[enum_dict_pos][grade_enum]

            # Append row index only if this enum appears in <50% of the range
            if count < (total_rows / 2):
                matching_indices = sub_df[sub_df == grade_enum].index.tolist()
                label += ": cycle\n"
                if matching_indices:
                    cycle_nums = [str(idx + 1) for idx in matching_indices]
                    label += ", ".join(cycle_nums)

            labels.append(label)
            bar_colors.append(color)
            counts.append(count)

        return counts, labels, bar_colors
    

    
    def app_id_to_cycle(self, app_id):
        """
        Converts the given app_id to a cycle
        App id's relate to cycles based on where they are found in the file. Cycle 1 will always 
        be the first cycle parsed in the file, which may be app id 1, but may be app id 68800
        App id 68801 may be at the end of file, which might be the 700th cycle parsed for example

        Args:
            app_id (int): the app id to be converted to a cycle number 

        Returns: 
            int: 0 if app_id not found in the realtime data, or the cycle number the app id
            corresponds to
        """

        #gives index, we want cycle
        matching_indices = self.dataframe.index[self.dataframe['ApplicationId'] == app_id]

        if not matching_indices.empty:
            return matching_indices[0] + 1  # first match
        
        else:
            return -1

        
    def get_min_and_max_app_id(self):
        """
        Gets the minimum and maximum application id from the realtime file

        Returns: 
            min_id (int): minimum application id found in the file 
            max_id (int): maxiumum ^
        """

        app_ids = set()

        for i in range(len(self.dataframe)):
            app_id = self.dataframe.iloc[i]['ApplicationId']
            app_ids.add(app_id)

        min_id = min(app_ids)
        max_id = max(app_ids)

        return min_id, max_id
    
    def generate_present_and_missing_app_id_lists_in_range(self, min_app_id_inclusive, max_app_id_exclusive):
        """
        Generates a set of all the present app id's and all the missing app id's within a range in the realtime file. 
        Sometimes firmware skips application id's, important to know when comparing against cycle nums 

        Args: 
            min_app_id_inclusive (int): the minimum app id that will be included in the set of present id's
            max_app_id_exclusive (int): the maximum app id + 1 that will be included in the set of present id's 

        Returns: 
            present_ids (set): set of all id's present within the range provided 
            missing_ids (set): set of all id's missing within the range provided

        """

        starttime = tm.time()
        present_ids = set()

        for i in range(len(self.dataframe)):

            app_id = int(self.dataframe.iloc[i]['ApplicationId'])

            if min_app_id_inclusive <= app_id < max_app_id_exclusive:
                present_ids.add(app_id)

        expected_ids = set(range(int(min_app_id_inclusive), int(max_app_id_exclusive)))
        missing_ids = expected_ids - present_ids

        etime = (tm.time() - starttime) 
        timems = etime * 1000
        print(f"Time to calculate missing app ids: {timems} ms")
        return present_ids, missing_ids















class RealtimeVisualizer(BaseVisualizer):
    """
    This class provides data analysis and plotting for realtime CSV file data. 
    It provides 1 graph that plots realtime cycle data by the cycle and by the range, 
    and appropriately displays on the graph any significant change values (dotted lines), 
    any corrected data (holes) and any out of bounds data (arrows). The metadata in the visualizer 
    is based almost entirely on the ranges and changes inputs in the range input frame 
    the user inputs and processes this data with. 
    """
    

    #Matplotlib is capable of using all the CSS4 colors. Find the list here: 
    # https://matplotlib.org/stable/gallery/color/named_colors.html - CSS Colors tab

    #Constants for realtime colors (CAN BE CHANGED)
    CURRENT_COLOR = 'red'
    PRESSURE_COLOR = 'blue' 
    DISTANCE_COLOR = 'green'

    #Constants for realtime sizes (CAN BE CHANGED)
    CURRENT_SIZE = 60
    PRESSURE_SIZE = 30
    DISTANCE_SIZE = 20

    def __init__(self, filepath, realtime_dataframe, realtime_metadata, ranges_and_changes_tuple):
        """
        Constructor for the Realtime visualizer class
        Creates it's parent BaseVisualizer, as well as 
        instantiates necessary variables, colors, and sizes for the graph. 

        Args: 
            See BaseVisualizer's __init__() args list 
        """
        
        super().__init__(filepath, realtime_dataframe, realtime_metadata, ranges_and_changes_tuple)

        #metadata is a list of data, each element being a cycle
        self.total_cycles = len(realtime_metadata)

        self.figure = Figure()
        self.figure.set_size_inches(4,3, forward=True)

        self.axes = {}

        self.colors = {}

        self.colors[self.current_label] = RealtimeVisualizer.CURRENT_COLOR
        self.colors[self.pressure_label] = RealtimeVisualizer.PRESSURE_COLOR
        self.colors[self.distance_label] = RealtimeVisualizer.DISTANCE_COLOR

        self.sizes = {}

        self.sizes[self.current_label] = RealtimeVisualizer.CURRENT_SIZE
        self.sizes[self.pressure_label] = RealtimeVisualizer.PRESSURE_SIZE
        self.sizes[self.distance_label] = RealtimeVisualizer.DISTANCE_SIZE
     

        

    

      
    def plot_realtime_cycle(self, cycle, columns_to_show_list):
        """
        Plots the realtime cycle data for the cycle provided. handles showing 
        corrected datapoints, if they were out of bounds low or high (arrows), as well 
        as drawing lines between the data point with a significatn change between. Will 
        draw multiple scatter plots on the same graph. 

        Args: 
            cycle (int): the cycle number to show 

            columns_to_show_list (list): list of column headers (strings) of the data to plot
        """

        start_index, stats, corrected_data, significant_changes, out_of_bounds = self.metadata[cycle - 1]

        #getting a valid column with stats that aren't 'None'
        col_with_stats = next(col for col in self.dataframe.columns if col not in ["ApplicationId", "Calculated CRC"])
        col_with_stats_index = self.dataframe.columns.get_loc(col_with_stats)
        #num of rows should be the same for all cols in the cycle, if not serious problem
        num_of_rows = stats[col_with_stats_index + 1][0]
        
        next_cycle_start_index = start_index + num_of_rows

        legend_data = {}

        for ydatalabel in columns_to_show_list:

            if ((ydatalabel == self.current_label) or (ydatalabel == self.distance_label)) and self.current_and_distance_label in self.axes:
                #these labels need to be combined..?
                current_ax = self.axes[self.current_and_distance_label]
                current_ax.set_ylabel(self.current_and_distance_label)
            else:
                current_ax = self.axes[ydatalabel]
                current_ax.set_ylabel(ydatalabel)

            if current_ax not in legend_data:
                legend_data[current_ax] = {"handles":[], "labels": []}

            # see doc. in data_loader on accessing dicts in metadata if confused
            target_col_index = self.dataframe.columns.get_loc(ydatalabel) 
            target_col_num = target_col_index + 1

            corrected_ydata_for_cycle = self.dataframe.iloc[start_index:next_cycle_start_index, target_col_index]
            out_of_bounds_points_low_x_values = []
            out_of_bounds_points_high_x_values = []

            x_to_corrected_y = {}
            for (col, row), corrected_datapoint in corrected_data.items():

                if col == target_col_num:
                    
                    x_value = start_index + row - 1
                    #will plot the corrected data by default
                    corrected_ydata_for_cycle[x_value] = corrected_datapoint
                    x_to_corrected_y[x_value] = corrected_datapoint


                     # - 1 becuase x values based on index in backend
                    #if you're here, you know the data was out of bounds. find and add line to graph 
                    out_of_bounds_datapoint = out_of_bounds[target_col_num, row]
                    if out_of_bounds_datapoint < corrected_datapoint:
                        #plot dashed line from corrected point to top 
                        out_of_bounds_points_low_x_values.append(x_value)
                    else:
                        #plot dahsed line from corrected point to bottom 
                        out_of_bounds_points_high_x_values.append(x_value)
                    #correcting the data so the graph doesn't plot out of bounds points

            changes_line = None
            changes_ydatalabel = f"Sig. Change in {ydatalabel}"

            for (col, row) in significant_changes.keys():
                if col == target_col_num:

                    if ((col, row) not in out_of_bounds) and ((col, row + 1) not in out_of_bounds):
                        #we know the change was between two valid data points, we care about htis
                        sig_line_x_start = start_index + row - 1
                        sig_line_x_end = sig_line_x_start + 1
                        sig_line_y_values  = self.dataframe.iloc[sig_line_x_start:sig_line_x_end+1, target_col_index]

                        changes_line, = current_ax.plot([sig_line_x_start, sig_line_x_end], sig_line_y_values, color=self.colors[ydatalabel], linestyle='--', label=ydatalabel)

            #plot corrected datapoints as hollow o's
            all_out_of_bounds_point_indices = out_of_bounds_points_low_x_values + out_of_bounds_points_high_x_values
            all_out_of_bounds_point_indices_for_ydata = [idx - start_index for idx in all_out_of_bounds_point_indices]
            corrected_y_points = corrected_ydata_for_cycle.iloc[all_out_of_bounds_point_indices_for_ydata]

            corrected_scatter = None
            corrected_ydatalabel = f"Corrected {ydatalabel}"
            if len(corrected_y_points) > 0: 
                corrected_scatter = current_ax.scatter(all_out_of_bounds_point_indices, corrected_y_points, 
                                                       color=self.colors[ydatalabel],  marker='o', facecolors='none', 
                                                       edgecolors=self.colors[ydatalabel], s=self.sizes[ydatalabel], label=ydatalabel)

            cycle_indices_relative_to_slice = range(len(corrected_ydata_for_cycle))
            not_on_out_of_bounds_x_values = [i for i in cycle_indices_relative_to_slice if i not in all_out_of_bounds_point_indices_for_ydata]
            x_filled = corrected_ydata_for_cycle.index.to_numpy()[not_on_out_of_bounds_x_values]
            y_filled = corrected_ydata_for_cycle.iloc[not_on_out_of_bounds_x_values]
            
            raw_scatter = None
            if len(y_filled) > 0:
            #plot the corrected datapoints
                raw_scatter = current_ax.scatter(x_filled, y_filled, color=self.colors[ydatalabel], s=self.sizes[ydatalabel],label=ydatalabel)
                
            for x_value in out_of_bounds_points_low_x_values:

                corrected_y = x_to_corrected_y[x_value]
                line_start = corrected_y  - 10
                line_end = corrected_y

                current_ax.vlines(x=x_value, ymin=line_start, ymax=corrected_y, colors=self.colors[ydatalabel], linestyle='-')
                            
                current_ax.annotate(
                    '',
                    xy=(x_value, line_end),          # arrow tip = corrected point (top)
                    xytext=(x_value, line_start),   # arrow tail = bottom (start of line)
                    arrowprops=dict(arrowstyle='-|>', color=self.colors[ydatalabel])
                )
            
            for x_value in out_of_bounds_points_high_x_values:

                corrected_y = x_to_corrected_y[x_value]
                line_start = corrected_y
                line_end = corrected_y + 10
                
                current_ax.vlines(x=x_value, ymin=corrected_y, ymax=line_end, colors=self.colors[ydatalabel], linestyle='-')   
                    
                # Arrow points DOWN from above the point TO the point
                current_ax.annotate(
                    '',
                    xy=(x_value, line_start),       # arrow tip = corrected point (bottom)
                    xytext=(x_value, line_end),     # arrow tail = top (start of arrow)
                    arrowprops=dict(arrowstyle='-|>', color=self.colors[ydatalabel])
                )

            
            current_ax.text(start_index, next_cycle_start_index, str(cycle), fontsize=10, ha='left', va='bottom')

            if raw_scatter is not None:
                legend_data[current_ax]["handles"].append(raw_scatter)
                legend_data[current_ax]["labels"].append(ydatalabel)
            
            if corrected_scatter is not None:
                legend_data[current_ax]["handles"].append(corrected_scatter)
                legend_data[current_ax]["labels"].append(corrected_ydatalabel)

            if changes_line is not None:
                legend_data[current_ax]["handles"].append(changes_line)
                legend_data[current_ax]["labels"].append(changes_ydatalabel)

        return legend_data


        
     


    def show_current_cycle_num(self, *columns_to_show):
        """
        Shows specifie data within the realtime visualizer's currently set cycle number
        to the graph with approrpriate legend and axes displaying. Handles the figure 
        and axes creation so that there are only a maximum of 2 y axes showing at a time, one on 
        either side of the graph, and are scaled appropriately

        Args: 
            *columns_to_show (list): a list of data column labels (strings) to show 
        """

        #clear all axes 
        self.figure.clf()
        self.axes.clear()
        self.figure.legends.clear()

        columns_to_show_list = list(columns_to_show)

        if len(columns_to_show_list) == 1:
            self.axes[columns_to_show_list[0]] = self.figure.add_subplot(111)
            self.axes[columns_to_show_list[0]].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")

        if len(columns_to_show_list) == 2:
            if self.current_label in columns_to_show_list and self.distance_label in columns_to_show_list:
                #combine the axes if they can be (current and distance)
                self.axes[self.current_and_distance_label] = self.figure.add_subplot(111)
                self.axes[self.current_and_distance_label].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")
            else: 
                self.axes[columns_to_show_list[0]] = self.figure.add_subplot(111)
                self.axes[columns_to_show_list[0]].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")
                
                self.axes[columns_to_show_list[1]] = self.axes[columns_to_show_list[0]].twinx()
                
        elif len(columns_to_show_list) > 2:
       
            #definitely combine the axis,
            self.axes[self.current_and_distance_label] = self.figure.add_subplot(111)
            self.axes[self.current_and_distance_label].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")
        
            self.axes[self.pressure_label] = self.axes[self.current_and_distance_label].twinx()

        legend_data = {}
        all_handles = []
        all_labels = []

        legend_data = self.plot_realtime_cycle(self.current_cycle, columns_to_show_list)
        
        for ax_data in legend_data.values():
            all_handles.extend(ax_data["handles"])
            all_labels.extend(ax_data["labels"])

        legend = self.figure.legend(all_handles, all_labels, loc='upper left')
        legend.set_draggable(True)


        

    def show_current_cycle_range(self, *columns_to_show):
        """
        Shows specifie data within the realtime visualizer's currently set cycle range
        to the graph with approrpriate legend and axes displaying. Handles the figure 
        and axes creation so that there are only a maximum of 2 y axes showing at a time, one on 
        either side of the graph, and are scaled appropriately

        Args: 
            *columns_to_show (list): a list of data column labels (strings) to show 
        """

        self.figure.legends.clear()

        #clear all axes 
        if self.axes:
            for ax in self.axes.values():
                self.figure.delaxes(ax)
            self.axes.clear()

        columns_to_show_list = list(columns_to_show)

        if len(columns_to_show_list) == 1:
            self.axes[columns_to_show_list[0]] = self.figure.add_subplot(111)
            self.axes[columns_to_show_list[0]].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")

        if len(columns_to_show_list) == 2:
            if self.current_label in columns_to_show_list and self.distance_label in columns_to_show_list:
                #combine the axes if they can be (current and distance)
                self.axes[self.current_and_distance_label] = self.figure.add_subplot(111)
                self.axes[self.current_and_distance_label].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")
            else: 
                self.axes[columns_to_show_list[0]] = self.figure.add_subplot(111)
                self.axes[columns_to_show_list[0]].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")
                
                self.axes[columns_to_show_list[1]] = self.axes[columns_to_show_list[0]].twinx()
                
        elif len(columns_to_show_list) > 2:
       
            #definitely combine the axis,
            self.axes[self.current_and_distance_label] = self.figure.add_subplot(111)
            self.axes[self.current_and_distance_label].set_title(f"Realtime Data in {self.filename}\nMPBID: {self.mpbid}")
        
            self.axes[self.pressure_label] = self.axes[self.current_and_distance_label].twinx()


        #add 1 to include the max cycle being displayed
        num_of_cycles = (self.current_cycle_range_max - self.current_cycle_range_min) + 1

        all_handles = []
        all_labels = []

        cycle_legend_data = {}

        for i in range(num_of_cycles):
            cycle_legend_data = self.plot_realtime_cycle(self.current_cycle_range_min + i, columns_to_show_list)

            for ax_data in cycle_legend_data.values():
                for handle, label in zip(ax_data["handles"], ax_data["labels"]):
                    if label not in all_labels:
                        all_handles.append(handle)
                        all_labels.append(label)
        
        legend = self.figure.legend(all_handles, all_labels, loc='upper right')
        legend.set_draggable(True)
            

            
            




    def app_id_to_cycle(self, app_id):
        """
        See Sequential Visualizer's app_id_to_cycle()
        """
        
        #loop through, add index to current index
        cycle = 0
        current_row_index = 0
        max_index = len(self.dataframe) - 1

        while (current_row_index < max_index):

            cycle += 1
            if (self.dataframe.iat[current_row_index, self.dataframe.columns.get_loc('ApplicationId')]) == app_id:
                return cycle
            current_row_index = self.metadata[cycle][self.MTDATA_CYCLE_START_IDX]

        return 0
    
    
    def get_min_and_max_app_id(self):
        """
        See Sequential Visualizer's get_min_and_max_app_id()
        """
        

        starttime = tm.time()

        app_ids = set()

        for i in range(len(self.metadata)):
            
            cycle_start = self.metadata[i][self.MTDATA_CYCLE_START_IDX]
            app_id = self.dataframe.iloc[cycle_start]['ApplicationId']
            app_ids.add(app_id)
        
        min_id = min(app_ids)
        max_id = max(app_ids)

        etime = (tm.time() - starttime) 
        timems = etime * 1000
        print(f"Time to calculate min and max app ids: {timems} ms")

        return min_id, max_id
            

    def generate_present_and_missing_app_id_lists_in_range(self, min_app_id_inlcusive, max_app_id_exclusive):
        """
        See SequentialVisualizers generate_present_and_missin_app_ids_in_range()
        """
        starttime = tm.time()
        present_ids = set()

        for i in range(len(self.metadata)):

            cycle_start = self.metadata[i][self.MTDATA_CYCLE_START_IDX]

            app_id = int(self.dataframe.iloc[cycle_start]['ApplicationId'])

            if min_app_id_inlcusive <= app_id < max_app_id_exclusive:
                present_ids.add(app_id)

        expected_ids = set(range(int(min_app_id_inlcusive), int(max_app_id_exclusive)))
        missing_ids = expected_ids - present_ids

        etime = (tm.time() - starttime) 
        timems = etime * 1000
        print(f"Time to calculate missing app ids: {timems} ms")
        return present_ids, missing_ids
    
   
    
    def write_report(self, filepath):
        """
        Writes a full report of all the realtime data compared against the 
        currently set ranges and changes values to a CSV file. See initial 
        writerow() calls to see the data formatting for this report

        Args:
            filepath (string): the CSV filepath to be written to
        """

        print(filepath)
        with open(filepath, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Current Min (A)', 'Current Max (A)', 'Current Significant Change (A)', 
                             'Pressure Min (PSI)', 'Pressure Max (PSI)', 'Pressure Significant Change (PSI)',
                             'Cycle Distance Min (mm)', 'Cycle Distance Max (mm)', 'Cycle Distance Significant Change (mm)'
                        ])
            writer.writerow(self.ranges_and_changes_tuple)
            writer.writerow([])
            writer.writerow(['Cycle', 'ApplicationId', 'Total Cycle Samples', 
                                'Column', 'Min (Within Set Ranges)', 'Max (Within Set Ranges)', 
                                'Average (Based on Corrected Data)', '# of Cycle Significant Change(s)', '# of Significant Changes Within Bounds', 
                                'Sample Numbers List of Sig. Change In Bounds', 'Sample Numbers List of Sig. Change Out of Bounds', 
                                '# Of Out of Bounds Values in Cycle', 'Out of Bounds Values' ])

            cols = list(self.dataframe.columns)
            pressure_col_idx = cols.index(self.pressure_label) 
            current_col_idx = cols.index(self.current_label) 
            distance_col_idx = cols.index(self.distance_label) 

            data_cols_indexes = [pressure_col_idx, current_col_idx, distance_col_idx]
            


            for idx in range(len(self.metadata)):

                cycle = idx + 1
                id_index = self.metadata[idx][self.MTDATA_CYCLE_START_IDX]
                id = self.dataframe.loc[id_index, 'ApplicationId']
                cycle_samples = self.metadata[idx][self.MTDATA_STATS_IDX][data_cols_indexes[0] + 1][0]
                column = "-"
                min = "-"
                max = "-"
                avg = "-"
                num_of_oob_vals = 0
                num_of_sig_changes = 0
                num_of_sig_changes_not_by_oob = 0
               
                significant_changes = self.metadata[idx][self.MTDATA_SIGNIFICANT_CHANGES_IDX]
                out_of_bounds = self.metadata[idx][self.MTDATA_OUT_OF_BOUNDS_IDX]
                

                for data_col_idx in data_cols_indexes:

                    num_of_oob_vals = 0
                    num_of_sig_changes = 0
                    num_of_sig_changes_not_by_oob = 0

                    in_bounds_sig_change_sample_nums = [] # list of tuples (start change sample num, end change sample num)
                    out_bounds_sig_change_sample_nums = [] # ^
                    oob_vals = []

                    column = cols[data_col_idx]

                    _, min, max, avg = self.metadata[idx][self.MTDATA_STATS_IDX][data_col_idx + 1]
                    
                    if out_of_bounds:

                        for (col, row), out_of_bounds_point in out_of_bounds.items():

                            if col == (data_col_idx + 1):
                                num_of_oob_vals += 1 
                                oob_vals.append(out_of_bounds_point)
                     
                    if significant_changes:

                        for (col, row) in significant_changes.keys():

                            if col == (data_col_idx + 1):
                                num_of_sig_changes += 1

                                if (col, row) not in out_of_bounds and (col, row + 1) not in out_of_bounds:
                                    num_of_sig_changes_not_by_oob += 1
                                    in_bounds_sig_change_sample_nums.append((row, row + 1))
                                else:
                                    out_bounds_sig_change_sample_nums.append((row, row + 1))

                    writer.writerow([cycle, id, cycle_samples, 
                                     column, min, max, 
                                     avg, num_of_sig_changes, num_of_sig_changes_not_by_oob, 
                                     str(in_bounds_sig_change_sample_nums), str(out_bounds_sig_change_sample_nums),
                                     num_of_oob_vals, *oob_vals])
                    
